export type Size = "XS" | "S" | "M" | "L" | "XL";

export type Kind = "shirt" | "blouse" | "trousers" | "wide" | "dress" | "blazer" | "tank" | "vest";

export type Category = "Blouses" | "Shirts" | "Trousers" | "Dresses" | "Office Essentials";

export interface Product {
  id: string;
  name: string;
  price: number;
  category: Category;
  kind: Kind;
  colors: string[];
  sizes: Size[];
  isNew: boolean;
  best: boolean;
  tone: number;
  added: number; // higher = newer
  description: string;
  fabric: string;
  details: string[];
  image?: string; // optional: paste a photo URL or data URI to replace the illustration
}

export interface CartLine { id: string; color: string; size: Size; qty: number }

export interface Customer {
  name: string; phone: string; email: string; address: string;
  city: string; district: string; postal: string; notes: string; payment: "cod" | "bank";
}
