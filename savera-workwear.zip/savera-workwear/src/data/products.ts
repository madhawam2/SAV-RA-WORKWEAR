import type { Category, Product, Size } from "../types";

export const ALL_SIZES: Size[] = ["XS", "S", "M", "L", "XL"];

export const MODEL_INFO = "Our model is 5'8\" (173 cm) with a 33\" bust, 25\" waist and 35\" hips, and wears size S.";

export const PRODUCTS: Product[] = [
  {
    id: "everyday-linen-shirt", name: "The Everyday Linen Shirt", price: 3490, category: "Shirts", kind: "shirt",
    colors: ["Ivory", "Sage", "Sand"], sizes: ["XS", "S", "M", "L", "XL"], isNew: true, best: true, tone: 0, added: 13,
    description: "A relaxed, breathable shirt in a soft linen blend. Wear it tucked into tailored trousers for the office or open over a tank on a casual Friday.",
    fabric: "55% linen, 45% viscose. Pre-washed for softness. Machine wash cool, iron while slightly damp.",
    details: ["Relaxed fit with a softly dropped shoulder", "Mother-of-pearl effect buttons", "Curved hem that works tucked or untucked", "Light enough for Colombo humidity"],
  },
  {
    id: "soft-tailored-trousers", name: "Soft Tailored Trousers", price: 3990, category: "Trousers", kind: "trousers",
    colors: ["Charcoal", "Sand", "Sage"], sizes: ["XS", "S", "M", "L", "XL"], isNew: true, best: false, tone: 2, added: 12,
    description: "Sharp in line, easy in feel. A high-rise trouser with a hidden stretch waistband that stays comfortable from the first meeting to the last.",
    fabric: "68% polyester, 28% viscose, 4% elastane. Wrinkle-resistant. Machine wash cold.",
    details: ["High rise with a flat, stretch-back waistband", "Front pleat for a clean drape", "Side pockets that sit flat", "Full length with a straight hem"],
  },
  {
    id: "modern-workday-blouse", name: "Modern Workday Blouse", price: 2990, category: "Blouses", kind: "blouse",
    colors: ["Ivory", "Blush", "Sage"], sizes: ["XS", "S", "M", "L"], isNew: true, best: false, tone: 1, added: 11,
    description: "A fluid V-neck blouse with a gentle gather at the hem. Light, quiet and easy to pair with almost anything in your wardrobe.",
    fabric: "100% recycled polyester crepe. Soft matte finish. Machine wash cold, hang to dry.",
    details: ["Relaxed V-neckline", "Short sleeve with a clean edge", "Slightly curved, longer back hem", "Does not cling in warm weather"],
  },
  {
    id: "minimal-midi-dress", name: "The Minimal Midi Dress", price: 4490, category: "Dresses", kind: "dress",
    colors: ["Sage", "Charcoal", "Oat"], sizes: ["XS", "S", "M", "L", "XL"], isNew: true, best: false, tone: 3, added: 10,
    description: "One piece, no styling required. A softly structured midi with a defined waist and a skirt that moves well when you walk.",
    fabric: "70% viscose, 30% polyester. Lined bodice. Machine wash gentle, cool iron.",
    details: ["Defined waist seam", "Hidden side zip", "Hits mid-calf on a 5'6\" frame", "Pockets in the side seams"],
  },
  {
    id: "sage-comfort-shirt", name: "Sage Comfort Shirt", price: 3490, category: "Shirts", kind: "shirt",
    colors: ["Sage", "Ivory", "Stone"], sizes: ["XS", "S", "M", "L", "XL"], isNew: true, best: false, tone: 1, added: 9,
    description: "Our softest everyday shirt, with a little stretch for long days at a desk and short commutes in between.",
    fabric: "97% cotton poplin, 3% elastane. Machine wash 30°C, medium iron.",
    details: ["Classic point collar", "Soft stretch for easy movement", "Regular fit, slightly cropped length", "Chest-level seam detail"],
  },
  {
    id: "essential-straight-pants", name: "Essential Straight Pants", price: 3790, category: "Trousers", kind: "trousers",
    colors: ["Stone", "Black", "Mocha"], sizes: ["XS", "S", "M", "L", "XL"], isNew: true, best: false, tone: 0, added: 8,
    description: "A clean straight leg in a fabric that holds its shape. The trouser you will reach for the most.",
    fabric: "72% polyester, 25% viscose, 3% elastane. Crease-resistant. Machine wash cold.",
    details: ["Mid-to-high rise", "Straight leg with a slight break", "Zip fly with a hook closure", "Belt loops and two back pockets"],
  },
  {
    id: "classic-wrap-blouse", name: "Classic Wrap Blouse", price: 3290, category: "Blouses", kind: "blouse",
    colors: ["Ivory", "Blush", "Charcoal"], sizes: ["XS", "S", "M", "L", "XL"], isNew: false, best: true, tone: 2, added: 7,
    description: "A flattering wrap front that works for every body, with enough coverage to feel polished and enough softness to feel easy.",
    fabric: "100% viscose. Fluid drape. Hand wash or gentle machine wash.",
    details: ["Wrap front with an inner tie", "Three-quarter sleeve", "Gently curved hem", "Opaque, even in Ivory"],
  },
  {
    id: "pleated-wide-leg-trousers", name: "Pleated Wide-Leg Trousers", price: 4290, category: "Trousers", kind: "wide",
    colors: ["Sand", "Charcoal", "Black"], sizes: ["XS", "S", "M", "L", "XL"], isNew: false, best: true, tone: 3, added: 6,
    description: "A generous leg with deep pleats that fall straight. Comfortable, cool and quietly dramatic.",
    fabric: "65% polyester, 30% viscose, 5% elastane. Machine wash cold.",
    details: ["High waist with double pleats", "Wide leg, full length", "Side and back pockets", "Cool to wear in warm weather"],
  },
  {
    id: "sleeveless-shift-dress", name: "Sleeveless Shift Dress", price: 4190, category: "Dresses", kind: "dress",
    colors: ["Charcoal", "Sage", "Oat"], sizes: ["XS", "S", "M", "L", "XL"], isNew: false, best: true, tone: 1, added: 5,
    description: "A clean-lined shift that layers under a blazer in the office and stands alone on weekends.",
    fabric: "75% polyester, 20% viscose, 5% elastane. Fully lined. Machine wash cold.",
    details: ["Round neckline", "Armholes cut to sit comfortably", "Knee-grazing midi length", "Back zip"],
  },
  {
    id: "relaxed-everyday-blazer", name: "Relaxed Everyday Blazer", price: 5990, category: "Office Essentials", kind: "blazer",
    colors: ["Oat", "Black", "Sage"], sizes: ["XS", "S", "M", "L", "XL"], isNew: false, best: true, tone: 2, added: 4,
    description: "The blazer that makes everything else look considered. Unstructured shoulders, a clean lapel, and a fabric that does not wrinkle in your bag.",
    fabric: "70% polyester, 27% viscose, 3% elastane. Lined. Dry clean or gentle machine wash.",
    details: ["Single-button closure", "Soft, lightly padded shoulder", "Two front pockets", "Sits at the hip"],
  },
  {
    id: "fine-knit-tank", name: "Fine-Knit Tank", price: 1990, category: "Office Essentials", kind: "tank",
    colors: ["Ivory", "Black", "Mocha"], sizes: ["XS", "S", "M", "L", "XL"], isNew: false, best: true, tone: 0, added: 3,
    description: "A smooth, fine-gauge tank that layers under shirts and blazers without bulk. Easy to wear on its own too.",
    fabric: "60% cotton, 35% nylon, 5% elastane. Soft stretch knit. Machine wash cold.",
    details: ["Scoop neckline", "Slim fit, hip length", "Seamless side panels", "Does not roll at the hem"],
  },
  {
    id: "tailored-waistcoat", name: "Tailored Waistcoat", price: 3590, category: "Office Essentials", kind: "vest",
    colors: ["Charcoal", "Stone", "Oat"], sizes: ["XS", "S", "M", "L"], isNew: false, best: false, tone: 3, added: 2,
    description: "A modern waistcoat with a fitted shape and a soft finish. Wear it over a shirt or on its own with straight trousers.",
    fabric: "70% polyester, 27% viscose, 3% elastane. Lined. Dry clean recommended.",
    details: ["V-neck with five-button front", "Adjustable back strap", "Slim fit", "Hip length"],
  },
  {
    id: "wrap-midi-dress", name: "The Wrap Midi Dress", price: 4790, category: "Dresses", kind: "dress",
    colors: ["Mocha", "Sage", "Black"], sizes: ["XS", "S", "M", "L", "XL"], isNew: false, best: false, tone: 0, added: 1,
    description: "A softly draped wrap dress that adjusts at the waist, so it fits well on the days you want it close and the days you do not.",
    fabric: "100% viscose twill. Fluid drape. Machine wash gentle.",
    details: ["Adjustable internal tie and outer wrap", "Elbow-length sleeves", "Midi length", "Easy to dress up with a blazer"],
  },
];

export const CATEGORIES: { id: string; label: string; route: string; match: Category | null }[] = [
  { id: "all", label: "All Products", route: "shop", match: null },
  { id: "blouses", label: "Blouses", route: "shop-blouses", match: "Blouses" },
  { id: "shirts", label: "Shirts", route: "shop-shirts", match: "Shirts" },
  { id: "trousers", label: "Trousers", route: "shop-trousers", match: "Trousers" },
  { id: "dresses", label: "Dresses", route: "shop-dresses", match: "Dresses" },
  { id: "essentials", label: "Office Essentials", route: "office-essentials", match: "Office Essentials" },
];
