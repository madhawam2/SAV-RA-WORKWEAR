import type { Size } from "../types";

export const LOOKS = [
  {
    id: "monday-minimal", name: "Monday Minimal", tone: 0,
    blurb: "A sharp, quiet start to the week. Structured layers in a calm, neutral palette.",
    pieces: [{ pid: "relaxed-everyday-blazer", color: "Oat" }, { pid: "soft-tailored-trousers", color: "Charcoal" }],
  },
  {
    id: "soft-neutral-days", name: "Soft Neutral Days", tone: 1,
    blurb: "Fluid fabrics and a tonal palette for the days that are all about focus.",
    pieces: [{ pid: "modern-workday-blouse", color: "Ivory" }, { pid: "pleated-wide-leg-trousers", color: "Sand" }],
  },
  {
    id: "friday-effortless", name: "Friday Effortless", tone: 3,
    blurb: "Relaxed enough for the end of the week, polished enough for a late meeting.",
    pieces: [{ pid: "everyday-linen-shirt", color: "Sage" }, { pid: "essential-straight-pants", color: "Stone" }],
  },
];

// Sample reviews: replace with real customer reviews before launch.
export const REVIEWS = [
  { name: "Dilini P.", stars: 5, product: "The Everyday Linen Shirt", text: "Finally workwear that gets through a full day in the Colombo heat. The linen is soft and the shirt still looks sharp at five o'clock." },
  { name: "Sanduni R.", stars: 5, product: "Soft Tailored Trousers", text: "The fit through the hip is perfect and the waistband is genuinely comfortable. I have already ordered a second pair in Sage." },
  { name: "Nimaya F.", stars: 4, product: "Modern Workday Blouse", text: "Lovely fabric and fast delivery to Kandy. I sized up for a looser fit and it was exactly what I wanted." },
];

export const DISTRICTS = [
  "Ampara","Anuradhapura","Badulla","Batticaloa","Colombo","Galle","Gampaha","Hambantota","Jaffna","Kalutara",
  "Kandy","Kegalle","Kilinochchi","Kurunegala","Mannar","Matale","Matara","Monaragala","Mullaitivu","Nuwara Eliya",
  "Polonnaruwa","Puttalam","Ratnapura","Trincomalee","Vavuniya",
];

export const SIZE_CHART: { size: Size; bust: string; waist: string; hip: string }[] = [
  { size: "XS", bust: "80", waist: "62", hip: "88" },
  { size: "S", bust: "84", waist: "66", hip: "92" },
  { size: "M", bust: "88", waist: "70", hip: "96" },
  { size: "L", bust: "94", waist: "76", hip: "102" },
  { size: "XL", bust: "100", waist: "82", hip: "108" },
];
