import { useEffect } from "react";
import { CartDrawer } from "./components/CartDrawer";
import { Footer } from "./components/Footer";
import { Header, MobileMenu, SearchOverlay } from "./components/Header";
import { AccountModal, QuickView, SizeGuide } from "./components/Modals";
import { Toast } from "./components/Toast";
import { CONFIG } from "./config";
import { AboutPage } from "./pages/About";
import { CheckoutPage, ConfirmationPage } from "./pages/Checkout";
import { CollectionsPage } from "./pages/Collections";
import { ContactPage } from "./pages/Contact";
import { HomePage } from "./pages/Home";
import { LookPage } from "./pages/Look";
import { NotFound } from "./pages/NotFound";
import { PolicyPage } from "./pages/Policy";
import { ProductPage } from "./pages/Product";
import { ShopPage } from "./pages/Shop";
import { WishlistPage } from "./pages/Wishlist";
import { useStore } from "./store/StoreContext";

export function Router() {
  const { route } = useStore();
  if (route === "home") return <HomePage />;
  if (route === "shop" || route.startsWith("shop-") || route === "new-arrivals" || route === "bestsellers" || route === "office-essentials") return <ShopPage route={route} />;
  if (route.startsWith("product-")) return <ProductPage id={route.slice(8)} />;
  if (route.startsWith("look-")) return <LookPage id={route.slice(5)} />;
  if (route === "collections") return <CollectionsPage />;
  if (route === "about") return <AboutPage />;
  if (route === "checkout") return <CheckoutPage />;
  if (route === "order-confirmed") return <ConfirmationPage />;
  if (route === "wishlist") return <WishlistPage />;
  if (route === "contact") return <ContactPage />;
  if (route.startsWith("policy-")) return <PolicyPage route={route} />;
  return <NotFound />;
}

export function pageKey(route: string) {
  if (route === "shop" || route.startsWith("shop-") || route === "new-arrivals" || route === "bestsellers" || route === "office-essentials") return "shop";
  return route;
}

export default function App() {
  const s = useStore();
  useEffect(() => { document.title = CONFIG.brand.name; }, []);
  return (
    <div>
      <Header />
      <main key={pageKey(s.route)} className="page min-h-[60vh] pb-4"><Router /></main>
      <Footer />
      <CartDrawer />
      <MobileMenu />
      <SearchOverlay />
      <QuickView />
      <SizeGuide />
      <AccountModal />
      <Toast />
    </div>
  );
}
