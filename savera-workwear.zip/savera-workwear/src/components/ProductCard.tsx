import { useState } from "react";
import type { Product } from "../types";
import { ProductImage } from "./Garment";
import { Icon } from "./Icon";
import { Swatch } from "./ui";
import { ALL_SIZES } from "../data/products";
import { fmt } from "../lib/helpers";
import { useStore } from "../store/StoreContext";

export function ProductCard({ p }: { p: Product }) {
  const s = useStore();
  const [color, setColor] = useState(p.colors[0]);
  const [picking, setPicking] = useState(false);
  const wished = s.wishlist.includes(p.id);
  return (
    <article className="group">
      <div className="relative aspect-[3/4] rounded-[14px] bg-softgray zoom">
        <a href={"#product-" + p.id} aria-label={"View " + p.name} className="block w-full h-full zt">
          <ProductImage p={p} color={color} />
        </a>
        {p.isNew && <span className="absolute left-3 top-3 bg-white/95 text-[10.5px] tracking-[.16em] uppercase font-semibold px-2.5 py-1.5 rounded-full">New Arrival</span>}
        <button type="button" onClick={() => s.toggleWish(p.id)} aria-pressed={wished} aria-label={wished ? "Remove from wishlist" : "Add to wishlist"}
          className="absolute right-2.5 top-2.5 w-11 h-11 grid place-items-center rounded-full bg-white/90 hover:bg-white transition-colors">
          <Icon name="Heart" size={19} className={wished ? "fill-charcoal" : ""} />
        </button>
        <button type="button" onClick={() => s.set({ quick: p.id })} aria-label={"Quick view " + p.name}
          className="absolute right-2.5 bottom-2.5 md:right-auto md:left-1/2 md:-translate-x-1/2 md:bottom-3 md:opacity-0 md:translate-y-2 md:group-hover:opacity-100 md:group-hover:translate-y-0 transition-all duration-500 flex items-center gap-2 h-11 px-3.5 md:px-5 rounded-full bg-white/95 hover:bg-white text-[11px] tracking-[.14em] uppercase font-semibold">
          <Icon name="Eye" size={16} /><span className="hidden md:inline">Quick View</span>
        </button>
        {picking && (
          <div className="absolute inset-x-0 bottom-0 p-3.5 pop" style={{ background: "rgba(255,255,255,.97)" }}>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-[11px] tracking-[.16em] uppercase font-semibold">Select size</span>
              <button type="button" onClick={() => setPicking(false)} aria-label="Close size picker" className="w-9 h-9 -mr-2 grid place-items-center"><Icon name="X" size={17} /></button>
            </div>
            <div className="flex flex-wrap gap-2">
              {ALL_SIZES.map((z) => (
                <button key={z} type="button" disabled={!p.sizes.includes(z)} className="chip" onClick={() => { s.addToCart(p.id, color, z, 1); setPicking(false); }}>{z}</button>
              ))}
            </div>
          </div>
        )}
      </div>
      <div className="pt-4">
        <div className="flex items-start justify-between gap-3">
          <h3 className="text-[15px] leading-snug font-medium"><a href={"#product-" + p.id} className="link-u">{p.name}</a></h3>
          <p className="text-[15px] font-medium whitespace-nowrap tabular-nums">{fmt(p.price)}</p>
        </div>
        <div className="flex items-center justify-between mt-1.5">
          <div className="flex -ml-[3px]">
            {p.colors.map((c) => <Swatch key={c} color={c} on={c === color} onClick={() => setColor(c)} size={18} />)}
          </div>
          <p className="text-[12px] text-muted tracking-wide">{p.sizes[0]} – {p.sizes[p.sizes.length - 1]}</p>
        </div>
        <button type="button" className="btn btn-line w-full mt-3.5 !min-h-[44px]" onClick={() => setPicking(true)}>
          <Icon name="ShoppingBag" size={16} /> Add to Cart
        </button>
      </div>
    </article>
  );
}

export function ProductGrid({ items, cols = "grid-cols-2 md:grid-cols-3 lg:grid-cols-4" }: { items: Product[]; cols?: string }) {
  return <div className={"grid gap-x-4 gap-y-9 md:gap-x-6 md:gap-y-12 " + cols}>{items.map((p) => <ProductCard key={p.id} p={p} />)}</div>;
}
