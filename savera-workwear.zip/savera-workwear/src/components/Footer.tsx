import type { Customer, Size } from "../types";
import { Logo } from "./Header";
import { Icon } from "./Icon";
import { CONFIG } from "../config";
import { CATEGORIES } from "../data/products";
import { useStore } from "../store/StoreContext";

export function Footer() {
  const s = useStore();
  const col = "grid gap-2.5 text-[14px] text-cream/75";
  const h = "text-[11.5px] tracking-[.2em] uppercase text-cream mb-4 font-semibold";
  return (
    <footer className="bg-charcoal text-cream mt-24">
      <div className="wrap pt-16 pb-10">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <Logo light />
            <p className="text-cream/75 text-[14.5px] leading-relaxed mt-5 max-w-[340px]">{CONFIG.brand.description}</p>
            <div className="flex gap-2 mt-6">
              {[["Instagram", "Instagram", CONFIG.social.instagram], ["Facebook", "Facebook", CONFIG.social.facebook], ["TikTok", "Music2", CONFIG.social.tiktok]].map(([label, icon, href]) => (
                <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={label} className="w-11 h-11 rounded-full border border-cream/25 grid place-items-center hover:bg-cream hover:text-charcoal transition-colors"><Icon name={icon} size={18} /></a>
              ))}
              <a href={"https://wa.me/" + CONFIG.whatsappNumber} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="w-11 h-11 rounded-full border border-cream/25 grid place-items-center hover:bg-cream hover:text-charcoal transition-colors"><Icon name="MessageCircle" size={18} /></a>
            </div>
          </div>
          <div className="lg:col-span-2">
            <h3 className={h}>Shop</h3>
            <ul className={col}>
              {CATEGORIES.map((c) => <li key={c.id}><a className="link-u" href={"#" + c.route}>{c.label}</a></li>)}
              <li><a className="link-u" href="#new-arrivals">New Arrivals</a></li>
            </ul>
          </div>
          <div className="lg:col-span-3">
            <h3 className={h}>Customer support</h3>
            <ul className={col}>
              <li><a className="link-u" href="#contact">Contact &amp; FAQs</a></li>
              <li><button type="button" className="link-u text-left" onClick={() => s.set({ sizeGuide: true })}>Size guide</button></li>
              <li><a className="link-u" href="#policy-shipping">Shipping &amp; delivery</a></li>
              <li><a className="link-u" href="#policy-returns">Returns &amp; exchanges</a></li>
            </ul>
          </div>
          <div className="lg:col-span-3">
            <h3 className={h}>Contact</h3>
            <ul className={col}>
              <li>{CONFIG.contact.address}</li>
              <li className="select-all">{CONFIG.contact.phone}</li>
              <li className="select-all">{CONFIG.contact.email}</li>
              <li>{CONFIG.contact.hours}</li>
            </ul>
          </div>
        </div>
        <div className="mt-14 pt-6 border-t border-cream/15 flex flex-col md:flex-row gap-4 md:items-center md:justify-between text-[12.5px] text-cream/60">
          <p>© {new Date().getFullYear()} {CONFIG.brand.name}. {CONFIG.brand.tagline}</p>
          <ul className="flex flex-wrap gap-x-6 gap-y-1">
            <li><a className="link-u" href="#policy-privacy">Privacy Policy</a></li>
            <li><a className="link-u" href="#policy-returns">Return Policy</a></li>
            <li><a className="link-u" href="#policy-shipping">Shipping Policy</a></li>
            <li><a className="link-u" href="#policy-terms">Terms &amp; Conditions</a></li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
