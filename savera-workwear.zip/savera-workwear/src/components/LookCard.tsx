import { Outfit } from "./Garment";
import { Icon } from "./Icon";
import { LOOKS } from "../data/content";
import { byId, fmt } from "../lib/helpers";

export function LookCard({ look }: { look: (typeof LOOKS)[number] }) {
  const prods = look.pieces.map((x) => ({ ...x, p: byId(x.pid)! }));
  const total = prods.reduce((a, x) => a + x.p.price, 0);
  return (
    <article className="group">
      <a href={"#look-" + look.id} className="block aspect-[3/4] rounded-[14px] overflow-hidden zoom" aria-label={"Shop the look: " + look.name}>
        <div className="w-full h-full zt"><Outfit tone={look.tone} pieces={prods.map((x) => ({ kind: x.p.kind, color: x.color }))} /></div>
      </a>
      <h3 className="font-display text-[1.9rem] mt-5 leading-tight">{look.name}</h3>
      <p className="text-[14.5px] text-muted mt-1.5 leading-relaxed">{look.blurb}</p>
      <ul className="mt-4 text-[13.5px] grid gap-1.5">
        {prods.map((x) => <li key={x.pid} className="flex justify-between gap-4"><span>{x.p.name} <span className="text-muted">· {x.color}</span></span><span className="tabular-nums">{fmt(x.p.price)}</span></li>)}
      </ul>
      <div className="flex items-center justify-between mt-5 pt-4 border-t border-line">
        <p className="text-[13.5px]">Full look <b className="tabular-nums ml-1">{fmt(total)}</b></p>
        <a href={"#look-" + look.id} className="inline-flex items-center gap-2 text-[11.5px] tracking-[.16em] uppercase font-semibold link-u">Shop the Look <Icon name="ArrowRight" size={14} /></a>
      </div>
    </article>
  );
}
