import { useState, useEffect, useMemo, useRef } from "react";
import { ProductImage } from "./Garment";
import { Icon } from "./Icon";
import { Panel } from "./ui";
import { CONFIG } from "../config";
import { CATEGORIES } from "../data/products";
import { fmt, searchProducts } from "../lib/helpers";
import { useStore } from "../store/StoreContext";

export const NAV = [
  { label: "Home", route: "home" },
  { label: "Shop", route: "shop" },
  { label: "New Arrivals", route: "new-arrivals" },
  { label: "Office Essentials", route: "office-essentials" },
  { label: "Collections", route: "collections" },
  { label: "About Us", route: "about" },
];

export function isActive(route: string, item: string) {
  if (item === "shop") return route === "shop" || route.startsWith("shop-") || route === "bestsellers";
  if (item === "collections") return route === "collections" || route.startsWith("look-");
  return route === item;
}

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <a href="#home" aria-label={CONFIG.brand.name + " home"} className={"font-display text-[1.9rem] md:text-[2.1rem] leading-none tracking-[.18em] pl-[.18em] " + (light ? "text-cream" : "")}>
      {CONFIG.brand.short}
    </a>
  );
}

export function Header() {
  const s = useStore();
  return (
    <div>
      <div className="bg-charcoal text-cream text-[12px] tracking-[.06em] text-center py-2.5">
        <div className="wrap">{CONFIG.announcement}</div>
      </div>
      <header className="sticky-top z-40 bg-cream/95 backdrop-blur border-b border-line/70">
        <div className="wrap h-[64px] lg:h-[76px] flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 lg:gap-0 lg:w-[200px]">
            <button type="button" className="lg:hidden w-11 h-11 -ml-2.5 grid place-items-center" onClick={() => s.set({ menu: true })} aria-label="Open menu"><Icon name="Menu" size={24} /></button>
            <div className="hidden lg:block"><Logo /></div>
          </div>
          <div className="lg:hidden"><Logo /></div>
          <nav className="hidden lg:flex items-center gap-9 text-[13.5px]" aria-label="Main">
            {NAV.map((n) => (
              <a key={n.route} href={"#" + n.route} className={"link-u py-2 " + (isActive(s.route, n.route) ? "on font-semibold" : "")}>{n.label}</a>
            ))}
          </nav>
          <div className="flex items-center justify-end gap-0.5 lg:w-[200px]">
            <button type="button" className="w-11 h-11 grid place-items-center" onClick={() => s.set({ search: true })} aria-label="Search"><Icon name="Search" size={21} /></button>
            <a href="#wishlist" className="hidden sm:grid relative w-11 h-11 place-items-center" aria-label={"Wishlist, " + s.wishlist.length + " items"}>
              <Icon name="Heart" size={21} />
              {s.wishlist.length > 0 && <span className="absolute top-1.5 right-1 min-w-[16px] h-4 px-1 rounded-full bg-sagedeep text-white text-[10px] grid place-items-center">{s.wishlist.length}</span>}
            </a>
            <button type="button" className="hidden sm:grid w-11 h-11 place-items-center" onClick={() => s.set({ account: true })} aria-label="Account"><Icon name="User" size={21} /></button>
            <button type="button" className="relative w-11 h-11 grid place-items-center" onClick={() => s.set({ cart: true })} aria-label={"Shopping bag, " + s.totals.count + " items"}>
              <Icon name="ShoppingBag" size={21} />
              {s.totals.count > 0 && <span className="absolute top-1 right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-charcoal text-cream text-[10.5px] grid place-items-center tabular-nums">{s.totals.count}</span>}
            </button>
          </div>
        </div>
      </header>
    </div>
  );
}

export function MobileMenu() {
  const s = useStore();
  return (
    <Panel open={s.ui.menu} onClose={() => s.set({ menu: false })} side="left" label="Menu">
      <div className="flex items-center justify-between px-5 h-[64px] border-b border-line">
        <Logo />
        <button type="button" className="w-11 h-11 -mr-2 grid place-items-center" onClick={() => s.set({ menu: false })} aria-label="Close menu"><Icon name="X" size={22} /></button>
      </div>
      <nav className="flex-1 overflow-y-auto px-5 py-4" aria-label="Mobile">
        {NAV.map((n) => (
          <a key={n.route} href={"#" + n.route} className="flex items-center justify-between h-14 border-b border-line/70 font-display text-[1.7rem]">
            {n.label}<Icon name="ChevronRight" size={18} />
          </a>
        ))}
        <p className="eyebrow mt-8 mb-2">Shop by category</p>
        <div className="grid grid-cols-2 gap-x-4">
          {CATEGORIES.slice(1).map((c) => <a key={c.id} href={"#" + c.route} className="h-11 flex items-center text-[14px]">{c.label}</a>)}
        </div>
        <div className="mt-8 grid gap-3">
          <button type="button" className="btn btn-line" onClick={() => s.set({ menu: false, account: true })}><Icon name="User" size={16} /> Account</button>
          <a href="#wishlist" className="btn btn-line"><Icon name="Heart" size={16} /> Wishlist ({s.wishlist.length})</a>
        </div>
      </nav>
    </Panel>
  );
}

export function SearchOverlay() {
  const s = useStore();
  const [q, setQ] = useState("");
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => { if (s.ui.search) setTimeout(() => ref.current && ref.current.focus(), 200); }, [s.ui.search]);
  useEffect(() => {
    if (!s.ui.search) return;
    const h = (e: KeyboardEvent) => { if (e.key === "Escape") s.set({ search: false }); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [s.ui.search]);
  const results = useMemo(() => (q.trim() ? searchProducts(q).slice(0, 5) : []), [q]);
  const submit = (e: any) => { e.preventDefault(); s.setQuery(q); s.closeAll(); location.hash = "shop"; };
  const open = s.ui.search;
  return (
    <div className={"fixed inset-0 z-[105] " + (open ? "" : "pointer-events-none")} aria-hidden={!open}>
      <div onClick={() => s.set({ search: false })} className={"absolute inset-0 bg-charcoal/40 transition-opacity duration-500 " + (open ? "opacity-100" : "opacity-0")} />
      <div role="dialog" aria-modal="true" aria-label="Search" className={"absolute inset-x-0 top-0 bg-cream shadow-xl transition-transform duration-500 ease-[cubic-bezier(.2,.7,.2,1)] " + (open ? "translate-y-0" : "-translate-y-full")} style={{ paddingTop: "env(safe-area-inset-top,0px)" }}>
        <div className="wrap py-5 md:py-8">
          <form onSubmit={submit} className="flex items-center gap-3 border-b border-charcoal pb-3">
            <Icon name="Search" size={22} />
            <input ref={ref} id="site-search" value={q} onChange={(e: any) => setQ(e.target.value)} placeholder="Search blouses, trousers, dresses…" className="flex-1 bg-transparent outline-none font-display text-[1.6rem] md:text-[2rem] placeholder:text-charcoal/35 min-w-0" aria-label="Search products" />
            <button type="button" onClick={() => s.set({ search: false })} className="w-11 h-11 grid place-items-center" aria-label="Close search"><Icon name="X" size={22} /></button>
          </form>
          {q.trim() === "" ? (
            <div className="pt-5 pb-3">
              <p className="eyebrow mb-3">Popular searches</p>
              <div className="flex flex-wrap gap-2">
                {["linen shirt", "trousers", "midi dress", "blazer", "sage"].map((t) => <button key={t} type="button" className="chip" onClick={() => setQ(t)}>{t}</button>)}
              </div>
            </div>
          ) : (
            <div className="pt-4 pb-2">
              {results.length === 0 ? <p className="text-muted py-4">No products match “{q}”.</p> : (
                <ul>
                  {results.map((p) => (
                    <li key={p.id}>
                      <a href={"#product-" + p.id} className="flex items-center gap-4 py-2.5 hover:bg-white/70 rounded-lg px-2 -mx-2">
                        <span className="w-14 aspect-[3/4] rounded-md overflow-hidden bg-softgray block"><ProductImage p={p} color={p.colors[0]} /></span>
                        <span className="flex-1 text-[15px]">{p.name}<span className="block text-[12.5px] text-muted">{p.category}</span></span>
                        <span className="text-[14px] tabular-nums">{fmt(p.price)}</span>
                      </a>
                    </li>
                  ))}
                </ul>
              )}
              <button type="button" onClick={submit} className="btn btn-dark mt-3">See all results</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
