import type { CartLine, Size } from "../types";
import { ProductImage } from "./Garment";
import { Icon } from "./Icon";
import { Panel, Qty } from "./ui";
import { CONFIG } from "../config";
import { byId, fmt, lineKey } from "../lib/helpers";
import { buildWhatsAppMessage, waLink } from "../lib/whatsapp";
import { useStore } from "../store/StoreContext";

export function CartLineItem({ l }: { l: CartLine }) {
  const s = useStore();
  const p = byId(l.id)!;
  const key = lineKey(l);
  return (
    <li className="flex gap-4 py-5 border-b border-line/70">
      <a href={"#product-" + p.id} className="w-[88px] shrink-0 aspect-[3/4] rounded-lg overflow-hidden bg-softgray block"><ProductImage p={p} color={l.color} /></a>
      <div className="flex-1 min-w-0">
        <div className="flex justify-between gap-3">
          <a href={"#product-" + p.id} className="text-[14.5px] font-medium leading-snug">{p.name}</a>
          <button type="button" onClick={() => s.removeLine(key)} aria-label={"Remove " + p.name} className="w-9 h-9 -mt-1.5 -mr-2 grid place-items-center text-muted hover:text-charcoal"><Icon name="Trash2" size={17} /></button>
        </div>
        <p className="text-[13.5px] mt-0.5 tabular-nums">{fmt(p.price)}</p>
        <div className="flex gap-2 mt-2.5">
          <select className="field field-sm !w-auto" aria-label="Colour" value={l.color} onChange={(e: any) => s.changeVariant(key, { color: e.target.value })}>
            {p.colors.map((c) => <option key={c}>{c}</option>)}
          </select>
          <select className="field field-sm !w-auto" aria-label="Size" value={l.size} onChange={(e: any) => s.changeVariant(key, { size: e.target.value })}>
            {p.sizes.map((z) => <option key={z}>{z}</option>)}
          </select>
        </div>
        <div className="flex items-center justify-between mt-3">
          <Qty small qty={l.qty} setQty={(n) => s.setQty(key, n)} />
          <p className="text-[14.5px] font-medium tabular-nums">{fmt(p.price * l.qty)}</p>
        </div>
      </div>
    </li>
  );
}

export function FreeDeliveryBar({ subtotal }: { subtotal: number }) {
  const left = Math.max(0, CONFIG.freeDeliveryOver - subtotal);
  const pct = Math.min(100, (subtotal / CONFIG.freeDeliveryOver) * 100);
  return (
    <div>
      <p className="text-[13px]">{left === 0 ? "You have unlocked free delivery." : <span>Add <b className="tabular-nums">{fmt(left)}</b> more for free delivery.</span>}</p>
      <div className="h-1.5 rounded-full bg-gray mt-2 overflow-hidden"><div className="h-full bg-sagedeep transition-all duration-700" style={{ width: pct + "%" }} /></div>
    </div>
  );
}

export function CartDrawer() {
  const s = useStore();
  const empty = s.cart.length === 0;
  const msg = buildWhatsAppMessage(s.cart, s.customer, s.totals.subtotal, s.totals.delivery);
  return (
    <Panel open={s.ui.cart} onClose={() => s.set({ cart: false })} label="Shopping bag">
      <div className="flex items-center justify-between px-5 h-[64px] border-b border-line shrink-0">
        <h2 className="font-display text-[1.7rem]">Your bag <span className="text-muted text-[1.1rem]">({s.totals.count})</span></h2>
        <button type="button" className="w-11 h-11 -mr-2 grid place-items-center" onClick={() => s.set({ cart: false })} aria-label="Close bag"><Icon name="X" size={22} /></button>
      </div>
      {empty ? (
        <div className="flex-1 grid place-items-center px-8 text-center">
          <div>
            <div className="mx-auto w-16 h-16 rounded-full bg-beige grid place-items-center mb-5"><Icon name="ShoppingBag" size={26} /></div>
            <h3 className="font-display text-[1.9rem]">Your bag is empty</h3>
            <p className="text-muted text-[14.5px] mt-2 max-w-[280px] mx-auto">Add a few pieces and they will be waiting here.</p>
            <a href="#shop" className="btn btn-dark mt-6" onClick={() => s.set({ cart: false })}>Start shopping</a>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col min-h-0">
          <div className="px-5 pt-4 shrink-0"><FreeDeliveryBar subtotal={s.totals.subtotal} /></div>
          <ul className="flex-1 overflow-y-auto px-5">{s.cart.map((l: CartLine) => <CartLineItem key={lineKey(l)} l={l} />)}</ul>
          <div className="px-5 py-5 border-t border-line bg-white/60 shrink-0">
            <dl className="text-[14px] grid gap-1.5 tabular-nums">
              <div className="flex justify-between"><dt className="text-muted">Subtotal</dt><dd>{fmt(s.totals.subtotal)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Delivery</dt><dd>{s.totals.delivery === 0 ? "Free" : fmt(s.totals.delivery)}</dd></div>
              <div className="flex justify-between text-[16px] font-semibold pt-2 mt-1 border-t border-line"><dt>Total</dt><dd>{fmt(s.totals.total)}</dd></div>
            </dl>
            <a href="#checkout" className="btn btn-dark w-full mt-4" onClick={() => s.set({ cart: false })}>Checkout</a>
            <a href={waLink(msg)} target="_blank" rel="noopener noreferrer" className="btn btn-line w-full mt-2.5"><Icon name="MessageCircle" size={17} /> Order via WhatsApp</a>
          </div>
        </div>
      )}
    </Panel>
  );
}
