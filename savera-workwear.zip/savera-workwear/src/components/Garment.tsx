import type { Kind, Product } from "../types";
import { SWATCH, isDark, mix } from "../lib/helpers";

//     Give a product an `image` URL and it will be used instead.
export const TONES = [["#F0EBE1", "#E3DACA"], ["#EAEDE6", "#D9DFD3"], ["#EEECE7", "#DEDAD1"], ["#E8E2D5", "#D8CFBD"]];

export const BOTTOMS = ["trousers", "wide"];

export function GarmentShape({ kind, color, front = true }: { kind: Kind; color: string; front?: boolean }) {
  const base = SWATCH[color] || "#D9CBB4";
  const dark = isDark(base);
  const hi = mix(base, "#FFFFFF", dark ? 0.16 : 0.3);
  const deep = mix(base, "#000000", 0.2);
  const line = mix(base, "#000000", 0.3);
  const btn = mix(base, dark ? "#FFFFFF" : "#000000", 0.5);
  const sw: any = { stroke: line, strokeWidth: 1.1, strokeLinejoin: "round", strokeLinecap: "round" };
  const seam: any = { stroke: line, strokeWidth: 0.9, strokeOpacity: 0.55, fill: "none", strokeLinecap: "round" };

  switch (kind) {
    case "shirt":
      return (
        <g>
          <path d="M118 84 L150 96 L182 84 L236 108 L262 232 L236 240 L214 150 L212 338 L88 338 L86 150 L64 240 L38 232 L64 108 Z" fill={base} {...sw} />
          <path d="M64 108 L86 150 M236 108 L214 150" {...seam} />
          <path d="M43 220 L67 228 M257 220 L233 228" {...seam} />
          {front ? (
            <g>
              <path d="M114 82 L150 98 L138 128 L104 100 Z" fill={hi} {...sw} />
              <path d="M186 82 L150 98 L162 128 L196 100 Z" fill={hi} {...sw} />
              <path d="M150 98 L150 338" {...seam} />
              {[140, 182, 224, 266, 308].map((y) => <circle key={y} cx="150" cy={y} r="2.6" fill={btn} />)}
              <path d="M170 160 L194 160 L194 184 L170 184 Z" {...seam} />
            </g>
          ) : (
            <g>
              <path d="M118 84 Q150 100 182 84" {...seam} />
              <path d="M90 120 Q150 138 210 120" {...seam} />
              <path d="M150 138 L150 338" {...seam} />
            </g>
          )}
        </g>
      );
    case "blouse":
      return (
        <g>
          <path d="M112 86 Q150 126 188 86 L238 108 L250 164 L214 160 L218 322 Q150 336 82 322 L86 160 L50 164 L62 108 Z" fill={base} {...sw} />
          {front ? (
            <g>
              <path d="M112 86 Q150 126 188 86 Q150 104 112 86 Z" fill={deep} fillOpacity="0.35" {...sw} />
              <path d="M98 214 Q150 228 202 214" {...seam} />
              <path d="M104 196 Q150 208 196 196" {...seam} />
            </g>
          ) : (
            <g>
              <path d="M112 86 Q150 100 188 86" {...seam} />
              <path d="M150 100 L150 326" {...seam} />
            </g>
          )}
          <path d="M62 108 L86 160 M238 108 L214 160" {...seam} />
        </g>
      );
    case "trousers":
      return (
        <g>
          <path d="M104 82 L196 82 L208 150 L211 344 L158 344 L152 176 L148 176 L142 344 L89 344 L92 150 Z" fill={base} {...sw} />
          <path d="M104 82 L196 82 L197 98 L103 98 Z" fill={deep} fillOpacity="0.28" {...sw} />
          {front ? (
            <g>
              <path d="M150 98 L150 176" {...seam} />
              <path d="M124 98 L121 160 M176 98 L179 160" {...seam} />
              <path d="M104 108 Q120 124 114 148 M196 108 Q180 124 186 148" {...seam} />
              <circle cx="150" cy="104" r="2.6" fill={btn} />
            </g>
          ) : (
            <g>
              <path d="M150 98 L150 176" {...seam} />
              <path d="M112 126 L136 126 M164 126 L188 126" {...seam} />
            </g>
          )}
          <path d="M101 330 L150 330 M150 330 L199 330" {...seam} />
        </g>
      );
    case "wide":
      return (
        <g>
          <path d="M100 82 L200 82 L218 150 L242 346 L160 346 L151 180 L149 180 L140 346 L58 346 L82 150 Z" fill={base} {...sw} />
          <path d="M100 82 L200 82 L201 98 L99 98 Z" fill={deep} fillOpacity="0.28" {...sw} />
          {front ? (
            <g>
              <path d="M128 98 L116 330 M172 98 L184 330" {...seam} />
              <path d="M150 98 L150 180" {...seam} />
              <path d="M100 108 Q116 124 110 150 M200 108 Q184 124 190 150" {...seam} />
              <circle cx="150" cy="104" r="2.6" fill={btn} />
            </g>
          ) : (
            <g>
              <path d="M150 98 L150 180" {...seam} />
              <path d="M112 126 L136 126 M164 126 L188 126" {...seam} />
            </g>
          )}
        </g>
      );
    case "dress":
      return (
        <g>
          <path d="M122 80 L138 80 Q150 108 162 80 L178 80 L184 150 L218 346 L82 346 L116 150 Z" fill={base} {...sw} />
          <path d="M116 150 L184 150 L186 168 L114 168 Z" fill={deep} fillOpacity="0.28" {...sw} />
          {front ? (
            <g>
              <path d="M150 168 L150 346 M130 172 L112 346 M170 172 L188 346" {...seam} />
              <path d="M122 80 Q150 124 178 80" {...seam} />
            </g>
          ) : (
            <g>
              <path d="M150 90 L150 346" {...seam} />
              <path d="M126 88 Q150 100 174 88" {...seam} />
            </g>
          )}
        </g>
      );
    case "blazer":
      return (
        <g>
          <path d="M116 84 L150 92 L184 84 L240 110 L266 272 L234 280 L214 160 L214 318 L86 318 L86 160 L66 280 L34 272 L60 110 Z" fill={base} {...sw} />
          <path d="M60 110 L86 160 M240 110 L214 160" {...seam} />
          {front ? (
            <g>
              <path d="M116 84 L150 96 L146 210 L110 142 L128 128 Z" fill={hi} {...sw} />
              <path d="M184 84 L150 96 L154 210 L190 142 L172 128 Z" fill={hi} {...sw} />
              <path d="M150 96 L150 318" {...seam} />
              <circle cx="150" cy="226" r="3.2" fill={btn} />
              <path d="M102 262 L136 262 M164 262 L198 262" {...seam} />
            </g>
          ) : (
            <g>
              <path d="M116 84 Q150 100 184 84" {...seam} />
              <path d="M150 100 L150 318" {...seam} />
            </g>
          )}
        </g>
      );
    case "tank":
      return (
        <g>
          <path d="M124 84 L138 84 Q150 124 162 84 L176 84 L188 140 L202 322 Q150 336 98 322 L112 140 Z" fill={base} {...sw} />
          {front ? <path d="M138 84 Q150 124 162 84" {...seam} /> : <path d="M138 84 Q150 98 162 84" {...seam} />}
          <path d="M112 140 Q150 150 188 140" {...seam} />
        </g>
      );
    case "vest":
      return (
        <g>
          <path d="M120 84 L142 84 L150 112 L158 84 L180 84 L192 150 L198 302 L150 326 L102 302 L108 150 Z" fill={base} {...sw} />
          {front ? (
            <g>
              <path d="M142 84 L150 112 L158 84" {...seam} />
              <path d="M150 112 L150 326" {...seam} />
              {[142, 178, 214, 250, 286].map((y) => <circle key={y} cx="150" cy={y} r="2.6" fill={btn} />)}
              <path d="M118 262 L136 262 M164 262 L182 262" {...seam} />
            </g>
          ) : (
            <g>
              <path d="M120 84 Q150 98 180 84" {...seam} />
              <path d="M110 250 L190 250" {...seam} />
              <path d="M150 98 L150 326" {...seam} />
            </g>
          )}
        </g>
      );
    default:
      return null;
  }
}

export function Hanger() {
  return (
    <g fill="none" stroke="#8D897C" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M150 64 L150 52 C150 44 160 44 160 36 C160 28 151 26 148 31" />
      <path d="M150 64 L98 94 M150 64 L202 94" />
    </g>
  );
}

export const DROP = { filter: "drop-shadow(0 8px 10px rgba(41,41,37,.17))" };

export function Garment({ kind, color, view = "front", tone = 0 }: { kind: Kind; color: string; view?: string; tone?: number }) {
  const [c1, c2] = TONES[tone % TONES.length];
  const id = "bg" + (tone % TONES.length) + view;
  const lifestyle = view === "lifestyle";
  const vb = view === "detail" ? "70 60 160 213" : "0 0 300 400";
  return (
    <svg viewBox={vb} className="w-full h-full block" role="img" aria-label={kind + " in " + color} preserveAspectRatio="xMidYMid slice">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={lifestyle ? "#CDD5C8" : c1} />
          <stop offset="1" stopColor={lifestyle ? "#B9C4B3" : c2} />
        </linearGradient>
      </defs>
      <rect x="-20" y="-20" width="340" height="440" fill={"url(#" + id + ")"} />
      {lifestyle && <path d="M52 420 V170 A98 98 0 0 1 248 170 V420 Z" fill="#fff" fillOpacity=".34" />}
      {lifestyle ? (
        <g style={DROP} transform="translate(150 62) scale(.86) translate(-150 -80)">
          <GarmentShape kind={kind} color={color} front />
        </g>
      ) : (
        <g>
          <Hanger />
          <g style={DROP}><GarmentShape kind={kind} color={color} front={view !== "back"} /></g>
        </g>
      )}
    </svg>
  );
}

export function ProductImage({ p, color, view = "front" }: { p: Product; color: string; view?: string }) {
  if (p.image) return <img src={p.image} alt={p.name} loading="lazy" className="w-full h-full object-cover" />;
  return <Garment kind={p.kind} color={color} view={view} tone={p.tone} />;
}

export function Outfit({ pieces, tone = 0, arch = true }: { pieces: { kind: Kind; color: string }[]; tone?: number; arch?: boolean }) {
  const [c1, c2] = TONES[tone % TONES.length];
  const bottom = pieces.find((p) => BOTTOMS.includes(p.kind));
  const top = pieces.find((p) => !BOTTOMS.includes(p.kind));
  const id = "of" + tone + (top ? top.kind : "") + (bottom ? bottom.kind : "");
  const s = bottom ? 0.72 : 0.92;
  return (
    <svg viewBox="0 0 300 400" className="w-full h-full block" role="img" aria-label="Outfit illustration" preserveAspectRatio="xMidYMid slice">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={c1} />
          <stop offset="1" stopColor={c2} />
        </linearGradient>
      </defs>
      <rect x="-20" y="-20" width="340" height="440" fill={"url(#" + id + ")"} />
      {arch && <path d="M46 420 V160 A104 104 0 0 1 254 160 V420 Z" fill="#fff" fillOpacity=".4" />}
      <g style={DROP}>
        {bottom && (
          <g transform={"translate(150 192) scale(" + s + ") translate(-150 -82)"}>
            <GarmentShape kind={bottom.kind} color={bottom.color} />
          </g>
        )}
        {top && (
          <g transform={"translate(150 " + (bottom ? 28 : 24) + ") scale(" + s + ") translate(-150 -80)"}>
            <GarmentShape kind={top.kind} color={top.color} />
          </g>
        )}
      </g>
    </svg>
  );
}
