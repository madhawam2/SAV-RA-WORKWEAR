import { useStore } from "../store/StoreContext";

export function Toast() {
  const s = useStore();
  return (
    <div className="fixed inset-x-0 z-[130] flex justify-center pointer-events-none" style={{ bottom: "calc(env(safe-area-inset-bottom,0px) + 88px)" }} aria-live="polite">
      {s.toast && <div className="pop bg-charcoal text-cream text-[13.5px] px-5 py-3 rounded-full shadow-xl">{s.toast}</div>}
    </div>
  );
}
