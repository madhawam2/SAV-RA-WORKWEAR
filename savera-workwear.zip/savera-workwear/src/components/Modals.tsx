import { useState, useEffect } from "react";
import type { Customer, Size } from "../types";
import { ProductImage } from "./Garment";
import { Modal, Qty, Swatch } from "./ui";
import { CONFIG } from "../config";
import { SIZE_CHART } from "../data/content";
import { ALL_SIZES, MODEL_INFO } from "../data/products";
import { byId, fmt } from "../lib/helpers";
import { useStore } from "../store/StoreContext";

export function QuickView() {
  const s = useStore();
  const p = s.ui.quick ? byId(s.ui.quick) : null;
  const [color, setColor] = useState("");
  const [size, setSize] = useState<Size | "">("");
  const [qty, setQty] = useState(1);
  const [err, setErr] = useState(false);
  useEffect(() => { if (p) { setColor(p.colors[0]); setSize(""); setQty(1); setErr(false); } }, [s.ui.quick]);
  return (
    <Modal open={!!p} onClose={() => s.set({ quick: null })} label="Quick view" wide>
      {p && (
        <div className="grid md:grid-cols-2">
          <div className="aspect-[3/4] md:aspect-auto md:min-h-[520px] bg-softgray"><ProductImage p={p} color={color} /></div>
          <div className="p-6 md:p-10 flex flex-col">
            <p className="eyebrow">{p.category}</p>
            <h2 className="font-display text-[2.2rem] leading-tight mt-2">{p.name}</h2>
            <p className="text-lg mt-2 tabular-nums">{fmt(p.price)}</p>
            <p className="text-[14.5px] text-muted mt-4 leading-relaxed">{p.description}</p>
            <p className="text-[13px] mt-6 mb-2"><span className="font-semibold">Colour:</span> {color}</p>
            <div className="flex -ml-[3px]">{p.colors.map((c) => <Swatch key={c} color={c} on={c === color} onClick={() => setColor(c)} size={26} />)}</div>
            <div className="flex items-center justify-between mt-6 mb-2">
              <p className="text-[13px]"><span className="font-semibold">Size:</span> {size || "Select"}</p>
              <button type="button" className="text-[12px] underline underline-offset-4" onClick={() => s.set({ sizeGuide: true })}>Size guide</button>
            </div>
            <div className="flex flex-wrap gap-2">
              {ALL_SIZES.map((z) => <button key={z} type="button" disabled={!p.sizes.includes(z)} className={"chip " + (size === z ? "on" : "")} onClick={() => { setSize(z); setErr(false); }}>{z}</button>)}
            </div>
            {err && <p className="text-[13px] text-[#9E3B2F] mt-2" role="alert">Please choose a size.</p>}
            <div className="flex gap-3 mt-7">
              <Qty qty={qty} setQty={setQty} />
              <button type="button" className="btn btn-dark flex-1" onClick={() => { if (!size) { setErr(true); return; } s.addToCart(p.id, color, size as Size, qty); }}>Add to Cart</button>
            </div>
            <a href={"#product-" + p.id} className="text-[13px] underline underline-offset-4 mt-6 self-start">View full details</a>
          </div>
        </div>
      )}
    </Modal>
  );
}

export function SizeGuide() {
  const s = useStore();
  return (
    <Modal open={s.ui.sizeGuide} onClose={() => s.set({ sizeGuide: false })} label="Size guide">
      <div className="p-7 md:p-9">
        <p className="eyebrow">Fit</p>
        <h2 className="font-display text-[2.2rem] leading-tight mt-2">Size guide</h2>
        <p className="text-[14px] text-muted mt-3">Body measurements in centimetres. If you are between sizes, choose the larger size for a relaxed fit.</p>
        <div className="overflow-x-auto mt-6">
          <table className="w-full text-[14px] text-left tabular-nums">
            <thead><tr className="border-b border-line text-[11px] tracking-[.14em] uppercase text-muted"><th className="py-3 pr-4 font-semibold">Size</th><th className="py-3 pr-4 font-semibold">Bust</th><th className="py-3 pr-4 font-semibold">Waist</th><th className="py-3 font-semibold">Hip</th></tr></thead>
            <tbody>
              {SIZE_CHART.map((r) => (
                <tr key={r.size} className="border-b border-line/70"><td className="py-3 pr-4 font-semibold">{r.size}</td><td className="py-3 pr-4">{r.bust}</td><td className="py-3 pr-4">{r.waist}</td><td className="py-3">{r.hip}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-[13px] text-muted mt-5">{MODEL_INFO}</p>
      </div>
    </Modal>
  );
}

export function AccountModal() {
  const s = useStore();
  return (
    <Modal open={s.ui.account} onClose={() => s.set({ account: false })} label="Account">
      <div className="p-7 md:p-9">
        <p className="eyebrow">Account</p>
        <h2 className="font-display text-[2.2rem] leading-tight mt-2">Your {CONFIG.brand.short}</h2>
        <p className="text-[14.5px] text-muted mt-3 leading-relaxed">Customer accounts are coming soon. Until then, your bag and wishlist are saved on this device, and you can order without signing in.</p>
        <div className="mt-6 grid gap-3">
          <a href="#wishlist" className="btn btn-dark">Wishlist ({s.wishlist.length})</a>
          <a href="#contact" className="btn btn-line">Contact us</a>
        </div>
      </div>
    </Modal>
  );
}
