import { useState, useEffect, useRef } from "react";
import { Icon } from "./Icon";
import { SWATCH } from "../lib/helpers";

export function Reveal({ children, className = "", delay = 0 }: { children: any; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!("IntersectionObserver" in window)) { setOn(true); return; }
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setOn(true); io.disconnect(); } }, { threshold: 0.1, rootMargin: "0px 0px -4% 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return <div ref={ref} style={{ transitionDelay: delay + "ms" }} className={"reveal " + (on ? "in " : "") + className}>{children}</div>;
}

export function Stars({ n }: { n: number }) {
  return (
    <div className="flex gap-0.5" role="img" aria-label={n + " out of 5 stars"}>
      {[1, 2, 3, 4, 5].map((i) => (
        <svg key={i} width="15" height="15" viewBox="0 0 24 24" fill={i <= n ? "#292925" : "none"} stroke="#292925" strokeWidth="1.4" strokeLinejoin="round">
          <path d="M12 3l2.7 5.8 6.3.7-4.7 4.3 1.3 6.2L12 17l-5.6 3 1.3-6.2L3 9.5l6.3-.7z" />
        </svg>
      ))}
    </div>
  );
}

export function SectionHead({ eyebrow, title, action }: { eyebrow?: string; title: any; action?: any }) {
  return (
    <div className="flex items-end justify-between gap-6 mb-8 lg:mb-12">
      <div>
        {eyebrow && <p className="eyebrow mb-3">{eyebrow}</p>}
        <h2 className="font-display text-[clamp(2rem,4.4vw,3.4rem)] leading-[1.05] text-balance">{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function Swatch({ color, on, onClick, size = 22 }: { color: string; on?: boolean; onClick?: () => void; size?: number }) {
  const inner = (
    <span className={"sw " + (on ? "on" : "")} style={{ background: SWATCH[color], width: size, height: size }} />
  );
  if (!onClick) return <span className="p-[3px]" title={color}>{inner}</span>;
  return (
    <button type="button" onClick={onClick} aria-label={color} aria-pressed={!!on} title={color} className="swb">
      {inner}
    </button>
  );
}

export function Panel({ open, onClose, side = "right", label, children }: { open: boolean; onClose: () => void; side?: "left" | "right"; label: string; children: any }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  const closed = side === "right" ? "translate-x-full" : "-translate-x-full";
  return (
    <div className={"fixed inset-0 z-[100] " + (open ? "" : "pointer-events-none")} aria-hidden={!open}>
      <div onClick={onClose} className={"absolute inset-0 bg-charcoal/40 transition-opacity duration-500 " + (open ? "opacity-100" : "opacity-0")} />
      <aside
        role="dialog" aria-modal="true" aria-label={label}
        className={"absolute top-0 bottom-0 flex flex-col w-[min(440px,92vw)] bg-cream shadow-2xl transition-transform duration-500 ease-[cubic-bezier(.2,.7,.2,1)] " + (side === "right" ? "right-0 " : "left-0 ") + (open ? "translate-x-0" : closed)}
        style={{ paddingTop: "env(safe-area-inset-top,0px)", paddingBottom: "env(safe-area-inset-bottom,0px)", [side === "right" ? "paddingRight" : "paddingLeft"]: "env(safe-area-inset-" + side + ",0px)" }}
      >
        {children}
      </aside>
    </div>
  );
}

export function Modal({ open, onClose, label, wide = false, children }: { open: boolean; onClose: () => void; label: string; wide?: boolean; children: any }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[110] flex items-end sm:items-center justify-center sm:p-6" style={{ paddingLeft: "max(0px,env(safe-area-inset-left,0px))", paddingRight: "max(0px,env(safe-area-inset-right,0px))" }}>
      <div onClick={onClose} className="absolute inset-0 bg-charcoal/45 fade" />
      <div role="dialog" aria-modal="true" aria-label={label}
        className={"pop relative bg-cream w-full max-h-[92vh] overflow-y-auto rounded-t-[18px] sm:rounded-[14px] shadow-2xl " + (wide ? "sm:max-w-[920px]" : "sm:max-w-[520px]")}
        style={{ paddingBottom: "env(safe-area-inset-bottom,0px)" }}>
        <button onClick={onClose} aria-label="Close" className="absolute right-3 top-3 z-10 w-11 h-11 grid place-items-center rounded-full bg-white/90 hover:bg-white transition-colors">
          <Icon name="X" size={20} />
        </button>
        {children}
      </div>
    </div>
  );
}

export function Qty({ qty, setQty, small = false }: { qty: number; setQty: (n: number) => void; small?: boolean }) {
  const h = small ? "h-10" : "h-12";
  return (
    <div className={"inline-flex items-center border border-line rounded-md bg-white " + h}>
      <button type="button" aria-label="Decrease quantity" disabled={qty <= 1} onClick={() => setQty(Math.max(1, qty - 1))} className={"w-11 grid place-items-center disabled:opacity-30 " + h}><Icon name="Minus" size={16} /></button>
      <span className="w-8 text-center text-[14px] tabular-nums" aria-live="polite">{qty}</span>
      <button type="button" aria-label="Increase quantity" disabled={qty >= 10} onClick={() => setQty(Math.min(10, qty + 1))} className={"w-11 grid place-items-center disabled:opacity-30 " + h}><Icon name="Plus" size={16} /></button>
    </div>
  );
}

export function Accordion({ title, children, open = false }: { title: string; children: any; open?: boolean }) {
  return (
    <details className="group border-t border-line last:border-b" open={open}>
      <summary className="flex items-center justify-between h-14 cursor-pointer list-none text-[14px] font-semibold">
        {title}<Icon name="ChevronDown" size={18} className="transition-transform duration-300 group-open:rotate-180" />
      </summary>
      <div className="pb-5 text-[14.5px] text-charcoal/80 leading-relaxed">{children}</div>
    </details>
  );
}
