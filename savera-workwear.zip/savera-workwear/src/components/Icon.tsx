import type { ComponentType } from "react";
import {
  ArrowRight, Banknote, Check, ChevronDown, ChevronLeft, ChevronRight, Clock, Eye, Facebook, Heart,
  Instagram, Lock, Mail, MapPin, Menu, MessageCircle, Minus, Music2, Phone, Plus, RotateCcw, Ruler,
  Search, ShoppingBag, SlidersHorizontal, Trash2, Truck, User, X,
} from "lucide-react";

// Only the icons the store uses are imported, which keeps the bundle small.
// To use another Lucide icon, import it above and add it to this map.
const ICONS: Record<string, ComponentType<any>> = {
  ArrowRight, Banknote, Check, ChevronDown, ChevronLeft, ChevronRight, Clock, Eye, Facebook, Heart,
  Instagram, Lock, Mail, MapPin, Menu, MessageCircle, Minus, Music2, Phone, Plus, RotateCcw, Ruler,
  Search, ShoppingBag, SlidersHorizontal, Trash2, Truck, User, X,
};

export function Icon({ name, size = 20, className = "", sw = 1.5 }: { name: string; size?: number; className?: string; sw?: number }) {
  const C = ICONS[name];
  if (!C) return <span style={{ display: "inline-block", width: size, height: size }} />;
  return <C size={size} strokeWidth={sw} className={className} aria-hidden="true" />;
}
