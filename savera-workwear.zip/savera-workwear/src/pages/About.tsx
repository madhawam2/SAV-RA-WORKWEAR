import { Outfit } from "../components/Garment";
import { CONFIG } from "../config";

export function AboutPage() {
  const values = [
    ["Comfort first", "Soft stretch, breathable fabrics and easy cuts, because Colombo is warm and your day is long."],
    ["Quietly polished", "Clean lines and a calm palette, so each piece works with the rest of your wardrobe."],
    ["Fairly priced", "Premium in feel and honest in price, with no seasonal markups."],
  ];
  return (
    <div>
      <section className="bg-beige">
        <div className="wrap py-16 lg:py-28 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="eyebrow">About us</p>
            <h1 className="font-display text-[clamp(2.8rem,6.6vw,5.4rem)] leading-[.98] mt-4 text-balance">Made for Your Everyday Ambition.</h1>
            <p className="text-[17px] text-charcoal/75 mt-6 leading-relaxed max-w-[520px]">{CONFIG.brand.name} began with a simple frustration: workwear that looked good on a hanger but felt wrong by lunchtime. We design for women who work, commute and lead in Sri Lanka, and we cut every piece to move with you.</p>
          </div>
          <div className="aspect-[4/5] max-w-[480px] w-full mx-auto lg:ml-auto rounded-t-[999px] rounded-b-[14px] overflow-hidden"><Outfit tone={2} arch={false} pieces={[{ kind: "dress", color: "Sage" }]} /></div>
        </div>
      </section>
      <section className="wrap py-20 lg:py-28">
        <div className="grid md:grid-cols-3 gap-10">
          {values.map(([t, d]) => <div key={t} className="border-t border-charcoal pt-5"><h2 className="font-display text-[1.9rem]">{t}</h2><p className="text-[15px] text-charcoal/75 mt-3 leading-relaxed">{d}</p></div>)}
        </div>
        <div className="mt-20 text-center">
          <p className="font-display text-[clamp(1.8rem,3.4vw,2.8rem)] italic">{CONFIG.brand.tagline}</p>
          <a href="#shop" className="btn btn-dark mt-8">Shop the Collection</a>
        </div>
      </section>
    </div>
  );
}
