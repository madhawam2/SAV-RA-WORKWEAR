import { CONFIG } from "../config";
import { fmt } from "../lib/helpers";
import { NotFound } from "./NotFound";

export const POLICIES: Record<string, { title: string; body: string[] }> = {
  "policy-privacy": { title: "Privacy Policy", body: [
    "We collect only what we need to process your order: your name, contact details and delivery address. We use them to deliver your order and to contact you about it.",
    "We never sell your information. Your bag and wishlist are stored on your own device.",
    "To ask what we hold about you, or to have it removed, email " + CONFIG.contact.email + ".",
    "This is sample policy text. Replace it with wording reviewed for your business before launch.",
  ] },
  "policy-returns": { title: "Return Policy", body: [
    "You may exchange or return unworn items with tags attached within 7 days of delivery.",
    "Contact us on WhatsApp or by email with your order number and we will arrange a pickup. Exchanges are free for the first order.",
    "Items that are worn, washed or altered cannot be returned. Refunds go to the original payment method, or by bank transfer for cash-on-delivery orders.",
    "This is sample policy text. Replace it with wording reviewed for your business before launch.",
  ] },
  "policy-shipping": { title: "Shipping Policy", body: [
    "We deliver islandwide. Colombo and suburbs take 1–2 working days; other districts take 2–4 working days.",
    "Delivery costs " + fmt(CONFIG.deliveryFee) + " and is free on orders over " + fmt(CONFIG.freeDeliveryOver) + ".",
    "Cash on delivery is available across Sri Lanka. You will receive a call or message from our courier before delivery.",
    "This is sample policy text. Replace it with wording reviewed for your business before launch.",
  ] },
  "policy-terms": { title: "Terms & Conditions", body: [
    "By placing an order you agree to provide accurate details and to accept delivery at the address you give.",
    "Prices are in Sri Lankan Rupees and may change without notice. An order is confirmed once we contact you.",
    "Colours may vary slightly between screens and the garment.",
    "This is sample policy text. Replace it with wording reviewed for your business before launch.",
  ] },
};

export function PolicyPage({ route }: { route: string }) {
  const p = POLICIES[route];
  if (!p) return <NotFound />;
  return (
    <div className="wrap pt-10 lg:pt-16 max-w-[760px]">
      <h1 className="font-display text-[clamp(2.6rem,6vw,4.4rem)] leading-none">{p.title}</h1>
      <div className="mt-8 grid gap-5 text-[16px] leading-relaxed text-charcoal/80">{p.body.map((t, i) => <p key={i}>{t}</p>)}</div>
    </div>
  );
}
