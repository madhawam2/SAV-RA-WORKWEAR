import type { Kind } from "../types";
import { Garment } from "../components/Garment";
import { Icon } from "../components/Icon";
import { LookCard } from "../components/LookCard";
import { LOOKS } from "../data/content";

export function CollectionsPage() {
  const cards = [
    { title: "Office Blouses", kind: "blouse" as Kind, color: "Ivory", tone: 0, route: "shop-blouses" },
    { title: "Comfortable Trousers", kind: "wide" as Kind, color: "Sand", tone: 1, route: "shop-trousers" },
    { title: "Midi Dresses", kind: "dress" as Kind, color: "Sage", tone: 2, route: "shop-dresses" },
    { title: "Everyday Essentials", kind: "blazer" as Kind, color: "Oat", tone: 3, route: "office-essentials" },
  ];
  return (
    <div className="wrap pt-10 lg:pt-16">
      <h1 className="font-display text-[clamp(2.6rem,6vw,4.6rem)] leading-none">Collections</h1>
      <p className="text-muted mt-3 max-w-[520px]">Outfits built around the way you work, and the categories to build your own.</p>
      <h2 className="font-display text-[2rem] mt-14 mb-8">Style your workday</h2>
      <div className="grid md:grid-cols-3 gap-10 md:gap-6 lg:gap-10">{LOOKS.map((l) => <LookCard key={l.id} look={l} />)}</div>
      <h2 className="font-display text-[2rem] mt-20 mb-8">Shop by category</h2>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        {cards.map((c) => (
          <a key={c.title} href={"#" + c.route} className="group block">
            <div className="aspect-[3/4] rounded-[14px] overflow-hidden zoom"><div className="w-full h-full zt"><Garment kind={c.kind} color={c.color} tone={c.tone} /></div></div>
            <h3 className="font-display text-[1.5rem] mt-4 leading-tight">{c.title}</h3>
            <span className="inline-flex items-center gap-2 mt-1.5 text-[11.5px] tracking-[.16em] uppercase font-semibold link-u">Shop Now <Icon name="ArrowRight" size={14} /></span>
          </a>
        ))}
      </div>
    </div>
  );
}
