import { useState } from "react";
import type { Size } from "../types";
import { Outfit, ProductImage } from "../components/Garment";
import { ProductGrid } from "../components/ProductCard";
import { SectionHead } from "../components/ui";
import { LOOKS } from "../data/content";
import { ALL_SIZES } from "../data/products";
import { byId, fmt } from "../lib/helpers";
import { NotFound } from "./NotFound";
import { useStore } from "../store/StoreContext";

export function LookPage({ id }: { id: string }) {
  const s = useStore();
  const look = LOOKS.find((l) => l.id === id);
  const [size, setSize] = useState<Size | "">("");
  const [err, setErr] = useState(false);
  if (!look) return <NotFound />;
  const prods = look.pieces.map((x) => ({ ...x, p: byId(x.pid)! }));
  const total = prods.reduce((a, x) => a + x.p.price, 0);
  const addAll = () => {
    if (!size) { setErr(true); return; }
    prods.forEach((x, i) => s.addToCart(x.pid, x.color, size as Size, 1, i === prods.length - 1));
  };
  return (
    <div className="wrap pt-10 lg:pt-16">
      <nav className="text-[12.5px] text-muted mb-6" aria-label="Breadcrumb"><a href="#home" className="link-u">Home</a> / <a href="#collections" className="link-u">Collections</a> / <span className="text-charcoal">{look.name}</span></nav>
      <div className="grid lg:grid-cols-2 gap-10 lg:gap-20 items-center">
        <div className="aspect-[3/4] max-w-[560px] w-full mx-auto lg:mx-0 rounded-[14px] overflow-hidden">
          <Outfit tone={look.tone} pieces={prods.map((x) => ({ kind: x.p.kind, color: x.color }))} />
        </div>
        <div>
          <p className="eyebrow">Shop the look</p>
          <h1 className="font-display text-[clamp(2.6rem,6vw,4.6rem)] leading-none mt-3">{look.name}</h1>
          <p className="text-[16.5px] text-charcoal/75 mt-5 leading-relaxed max-w-[480px]">{look.blurb}</p>
          <ul className="mt-8 grid gap-3">
            {prods.map((x) => (
              <li key={x.pid}><a href={"#product-" + x.pid} className="flex items-center gap-4 p-3 bg-white rounded-[12px] hover:shadow-md transition-shadow">
                <span className="w-14 aspect-[3/4] rounded-md overflow-hidden block"><ProductImage p={x.p} color={x.color} /></span>
                <span className="flex-1 text-[14.5px]">{x.p.name}<span className="block text-[12.5px] text-muted">{x.color}</span></span>
                <span className="tabular-nums text-[14px]">{fmt(x.p.price)}</span>
              </a></li>
            ))}
          </ul>
          <div className="mt-8">
            <p className="text-[13px] mb-2"><span className="font-semibold">Size for all pieces:</span> {size || "Select"}</p>
            <div className="flex flex-wrap gap-2">{ALL_SIZES.map((z) => <button key={z} type="button" className={"chip " + (size === z ? "on" : "")} aria-pressed={size === z} onClick={() => { setSize(z); setErr(false); }}>{z}</button>)}</div>
            {err && <p className="text-[13px] text-[#9E3B2F] mt-2" role="alert">Please choose a size.</p>}
            <p className="text-[12.5px] text-muted mt-2">You can change the size of each piece in your bag.</p>
          </div>
          <button type="button" className="btn btn-dark mt-6 w-full sm:w-auto" onClick={addAll}>Add the full look · {fmt(total)}</button>
        </div>
      </div>
      <section className="pt-24">
        <SectionHead eyebrow="The pieces" title="Shop each piece" />
        <ProductGrid items={prods.map((x) => x.p)} cols="grid-cols-2 md:grid-cols-3 lg:grid-cols-4" />
      </section>
    </div>
  );
}
