import { useState, useRef } from "react";
import type { Kind } from "../types";
import { Garment, Outfit } from "../components/Garment";
import { Icon } from "../components/Icon";
import { LookCard } from "../components/LookCard";
import { ProductCard, ProductGrid } from "../components/ProductCard";
import { Reveal, SectionHead, Stars } from "../components/ui";
import { LOOKS, REVIEWS } from "../data/content";
import { PRODUCTS } from "../data/products";
import { byId } from "../lib/helpers";

export function Hero() {
  const blazer = byId("relaxed-everyday-blazer")!;
  return (
    <section className="bg-beige">
      <div className="wrap grid lg:grid-cols-12 items-center gap-10 lg:gap-6 py-12 lg:py-0 lg:min-h-[700px]">
        <div className="lg:col-span-6 lg:py-24 lg:pr-10">
          <p className="eyebrow">New season · The Linen Edit</p>
          <h1 className="font-display text-[clamp(3rem,7.4vw,6.2rem)] leading-[.96] mt-6 text-balance">
            Your Everyday Workwear, <em className="text-sagedeep">Elevated.</em>
          </h1>
          <p className="text-[17px] md:text-[18px] text-charcoal/75 mt-6 max-w-[460px] leading-relaxed">Thoughtfully designed essentials for women who move with confidence.</p>
          <div className="flex flex-col sm:flex-row gap-3 mt-9">
            <a href="#shop" className="btn btn-dark">Shop the Collection</a>
            <a href="#new-arrivals" className="btn btn-line">Explore New Arrivals</a>
          </div>
        </div>
        <div className="lg:col-span-6 relative">
          <div className="relative mx-auto w-full max-w-[520px] lg:max-w-none lg:ml-auto lg:w-[84%] aspect-[3/4] rounded-t-[999px] rounded-b-[14px] overflow-hidden lg:translate-y-6">
            <Outfit tone={3} arch={false} pieces={[{ kind: "blazer", color: "Oat" }, { kind: "wide", color: "Charcoal" }]} />
          </div>
          <a href="#look-monday-minimal" className="absolute left-2 lg:left-0 bottom-6 lg:bottom-14 bg-white rounded-xl shadow-lg px-5 py-4 max-w-[240px]">
            <p className="eyebrow">Monday Minimal</p>
            <p className="font-display text-[1.25rem] leading-tight mt-1.5">{blazer.name} + Wide-Leg Trousers</p>
            <p className="text-[12.5px] mt-2 flex items-center gap-1.5 text-muted">Shop the look <Icon name="ArrowRight" size={14} /></p>
          </a>
        </div>
      </div>
    </section>
  );
}

export function TrustStrip() {
  const items = [["Truck", "Islandwide delivery"], ["RotateCcw", "7-day easy exchanges"], ["Banknote", "Cash on delivery"], ["MessageCircle", "Order via WhatsApp"]];
  return (
    <section className="border-y border-line/70 bg-white/50">
      <div className="wrap grid grid-cols-2 lg:grid-cols-4 gap-y-4 py-5">
        {items.map(([ic, t]) => (
          <div key={t} className="flex items-center gap-3 text-[13px]"><Icon name={ic} size={19} /><span>{t}</span></div>
        ))}
      </div>
    </section>
  );
}

export function CategoryCards() {
  const cards = [
    { title: "Office Blouses", kind: "blouse" as Kind, color: "Ivory", tone: 0, route: "shop-blouses" },
    { title: "Comfortable Trousers", kind: "wide" as Kind, color: "Sand", tone: 1, route: "shop-trousers" },
    { title: "Midi Dresses", kind: "dress" as Kind, color: "Sage", tone: 2, route: "shop-dresses" },
    { title: "Everyday Essentials", kind: "blazer" as Kind, color: "Oat", tone: 3, route: "office-essentials" },
  ];
  return (
    <section className="wrap pt-20 lg:pt-28">
      <Reveal><SectionHead eyebrow="Shop by category" title="The essentials, edited." /></Reveal>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        {cards.map((c, i) => (
          <Reveal key={c.title} delay={i * 80}>
            <a href={"#" + c.route} className="group block">
              <div className="aspect-[3/4] rounded-[14px] overflow-hidden zoom relative">
                <div className="w-full h-full zt"><Garment kind={c.kind} color={c.color} tone={c.tone} /></div>
              </div>
              <div className="flex items-center justify-between gap-3 mt-4">
                <h3 className="font-display text-[1.45rem] lg:text-[1.8rem] leading-tight">{c.title}</h3>
              </div>
              <span className="inline-flex items-center gap-2 mt-2 text-[11.5px] tracking-[.16em] uppercase font-semibold link-u">Shop Now <Icon name="ArrowRight" size={14} /></span>
            </a>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function NewArrivals() {
  const items = PRODUCTS.filter((p) => p.isNew).sort((a, b) => b.added - a.added).slice(0, 6);
  return (
    <section className="wrap pt-24 lg:pt-32">
      <Reveal><SectionHead eyebrow="Just landed" title="New Arrivals" action={<a href="#new-arrivals" className="hidden sm:inline-flex items-center gap-2 text-[12px] tracking-[.16em] uppercase font-semibold link-u">View all <Icon name="ArrowRight" size={14} /></a>} /></Reveal>
      <ProductGrid items={items} cols="grid-cols-2 md:grid-cols-3" />
      <a href="#new-arrivals" className="btn btn-line mt-10 sm:hidden w-full">View all new arrivals</a>
    </section>
  );
}

export function BrandStory() {
  return (
    <section className="bg-beige mt-24 lg:mt-32">
      <div className="wrap grid lg:grid-cols-2 gap-10 lg:gap-20 items-center py-16 lg:py-28">
        <Reveal>
          <div className="relative max-w-[520px] mx-auto lg:mx-0 w-full">
            <div className="aspect-[4/5] rounded-[14px] overflow-hidden">
              <Outfit tone={1} pieces={[{ kind: "shirt", color: "Ivory" }, { kind: "trousers", color: "Sage" }]} />
            </div>
            <p className="absolute -bottom-4 right-4 bg-cream text-[12px] tracking-[.14em] uppercase px-4 py-2.5 rounded-full shadow-md">Designed in Colombo</p>
          </div>
        </Reveal>
        <Reveal delay={120}>
          <p className="eyebrow">Our story</p>
          <h2 className="font-display text-[clamp(2.2rem,4.6vw,3.8rem)] leading-[1.04] mt-4 text-balance">Made for Your Everyday Ambition.</h2>
          <p className="text-[17px] text-charcoal/75 leading-relaxed mt-6 max-w-[520px]">Workwear should never mean compromising on comfort or style. We create thoughtfully designed essentials that make getting dressed for work effortless, confident, and comfortable.</p>
          <a href="#about" className="btn btn-dark mt-8">About Our Story</a>
        </Reveal>
      </div>
    </section>
  );
}

export function Bestsellers() {
  const items = PRODUCTS.filter((p) => p.best);
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => { const el = ref.current; if (el) el.scrollBy({ left: dir * el.clientWidth * 0.8, behavior: "smooth" }); };
  return (
    <section className="pt-24 lg:pt-32">
      <div className="wrap">
        <Reveal>
          <SectionHead eyebrow="Most loved" title="Bestsellers" action={
            <div className="flex gap-2">
              <button type="button" onClick={() => scroll(-1)} aria-label="Scroll left" className="w-11 h-11 rounded-full border border-charcoal/30 grid place-items-center hover:bg-charcoal hover:text-cream transition-colors"><Icon name="ChevronLeft" size={20} /></button>
              <button type="button" onClick={() => scroll(1)} aria-label="Scroll right" className="w-11 h-11 rounded-full border border-charcoal/30 grid place-items-center hover:bg-charcoal hover:text-cream transition-colors"><Icon name="ChevronRight" size={20} /></button>
            </div>
          } />
        </Reveal>
      </div>
      <div className="wrap">
        <div ref={ref} className="flex gap-4 lg:gap-6 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-2 -mx-1 px-1">
          {items.map((p) => (
            <div key={p.id} className="snap-start shrink-0 w-[68%] sm:w-[42%] md:w-[30%] lg:w-[23.4%]"><ProductCard p={p} /></div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function StyleYourWorkday() {
  return (
    <section className="wrap pt-24 lg:pt-32">
      <Reveal><SectionHead eyebrow="Outfit ideas" title="Style Your Workday" /></Reveal>
      <div className="grid md:grid-cols-3 gap-10 md:gap-6 lg:gap-10">
        {LOOKS.map((l, i) => <Reveal key={l.id} delay={i * 100}><LookCard look={l} /></Reveal>)}
      </div>
    </section>
  );
}

export function PromoBanner() {
  return (
    <section className="mt-24 lg:mt-32 bg-sage">
      <div className="wrap py-20 lg:py-28 text-center">
        <Reveal>
          <h2 className="font-display text-[clamp(2.4rem,6vw,5rem)] leading-[1.02] max-w-[820px] mx-auto text-balance">Feel Good. Look Confident. Every Day.</h2>
          <p className="text-[17px] mt-5 text-charcoal/80">Discover workwear designed around your lifestyle.</p>
          <a href="#shop" className="btn btn-light mt-9">Shop Now</a>
        </Reveal>
      </div>
    </section>
  );
}

export function Reviews() {
  return (
    <section className="wrap pt-24 lg:pt-32">
      <Reveal><SectionHead eyebrow="Kind words" title="Worn to work, loved by our customers." /></Reveal>
      <div className="grid md:grid-cols-3 gap-5 lg:gap-8">
        {REVIEWS.map((r, i) => (
          <Reveal key={r.name} delay={i * 90}>
            <figure className="bg-white rounded-[14px] p-7 lg:p-8 h-full flex flex-col">
              <Stars n={r.stars} />
              <blockquote className="font-display text-[1.45rem] leading-snug mt-5 flex-1">“{r.text}”</blockquote>
              <figcaption className="mt-6 pt-5 border-t border-line text-[13.5px]">
                <p className="font-semibold">{r.name}</p>
                <p className="text-muted">Purchased: {r.product}</p>
              </figcaption>
            </figure>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "error" | "done">("idle");
  const submit = (e: any) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setState("error"); return; }
    setState("done");
    // Connect this to your email provider (Mailchimp, Klaviyo, Brevo…) when you go live.
  };
  return (
    <section className="mt-24 lg:mt-32 bg-beige">
      <div className="wrap py-16 lg:py-24 grid lg:grid-cols-2 gap-10 items-center">
        <Reveal>
          <h2 className="font-display text-[clamp(2.2rem,4.6vw,3.8rem)] leading-[1.04]">Your Inbox, Styled.</h2>
          <p className="text-[16.5px] text-charcoal/75 mt-4 max-w-[460px] leading-relaxed">Be the first to discover new collections, exclusive offers, and everyday style inspiration.</p>
        </Reveal>
        <Reveal delay={100}>
          {state === "done" ? (
            <div className="bg-white rounded-[14px] p-7 pop" role="status">
              <p className="font-display text-[1.7rem]">Thank you.</p>
              <p className="text-muted mt-1">{email} is on the list. Your first note is on its way.</p>
            </div>
          ) : (
            <form onSubmit={submit} noValidate>
              <label htmlFor="newsletter-email" className="sr-only">Email address</label>
              <div className="flex flex-col sm:flex-row gap-3">
                <input id="newsletter-email" type="email" inputMode="email" autoComplete="email" placeholder="Your email address" value={email} onChange={(e: any) => { setEmail(e.target.value); setState("idle"); }} className={"field flex-1 " + (state === "error" ? "err" : "")} />
                <button type="submit" className="btn btn-dark">Subscribe</button>
              </div>
              {state === "error" && <p className="text-[13px] text-[#9E3B2F] mt-2" role="alert">Please enter a valid email address.</p>}
              <p className="text-[12px] text-muted mt-3">No spam. Unsubscribe whenever you like.</p>
            </form>
          )}
        </Reveal>
      </div>
    </section>
  );
}

export function HomePage() {
  return (
    <div>
      <Hero />
      <TrustStrip />
      <CategoryCards />
      <NewArrivals />
      <BrandStory />
      <Bestsellers />
      <StyleYourWorkday />
      <PromoBanner />
      <Reviews />
      <Newsletter />
    </div>
  );
}
