import { useState, useEffect, useRef } from "react";
import type { Product, Size } from "../types";
import { ProductImage } from "../components/Garment";
import { Icon } from "../components/Icon";
import { ProductGrid } from "../components/ProductCard";
import { Accordion, Qty, SectionHead, Swatch } from "../components/ui";
import { CONFIG } from "../config";
import { ALL_SIZES, CATEGORIES, MODEL_INFO, PRODUCTS } from "../data/products";
import { byId, fmt } from "../lib/helpers";
import { NotFound } from "./NotFound";
import { useStore } from "../store/StoreContext";

export function ProductPage({ id }: { id: string }) {
  const s = useStore();
  const p = byId(id);
  const [color, setColor] = useState(p ? p.colors[0] : "");
  const [size, setSize] = useState<Size | "">("");
  const [qty, setQty] = useState(1);
  const [view, setView] = useState("front");
  const [err, setErr] = useState(false);
  const sizeRef = useRef<HTMLDivElement>(null);
  useEffect(() => { if (p) { setColor(p.colors[0]); setSize(""); setQty(1); setView("front"); setErr(false); } }, [id]);

  if (!p) return <NotFound />;
  const wished = s.wishlist.includes(p.id);
  const views = [["front", "Front"], ["detail", "Detail"], ["lifestyle", "Styled"], ["back", "Back"]];
  const related = PRODUCTS.filter((x) => x.id !== p.id && x.category === p.category).concat(PRODUCTS.filter((x) => x.id !== p.id && x.category !== p.category)).slice(0, 4);

  const need = () => { setErr(true); if (sizeRef.current) sizeRef.current.scrollIntoView({ behavior: "smooth", block: "center" }); };
  const add = () => { if (!size) return need(); s.addToCart(p.id, color, size as Size, qty); };
  const buyNow = () => { if (!size) return need(); s.addToCart(p.id, color, size as Size, qty, false); location.hash = "checkout"; };

  return (
    <div className="pb-24 lg:pb-0">
      <div className="wrap pt-8 lg:pt-12">
        <nav className="text-[12.5px] text-muted mb-6" aria-label="Breadcrumb">
          <a href="#home" className="link-u">Home</a> / <a href="#shop" className="link-u">Shop</a> / <a href={"#" + (CATEGORIES.find((c) => c.match === p.category) || CATEGORIES[0]).route} className="link-u">{p.category}</a> / <span className="text-charcoal">{p.name}</span>
        </nav>
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-14">
          <div className="lg:col-span-7 grid lg:grid-cols-[84px_1fr] gap-3 lg:gap-4 items-start">
            <div className="order-2 lg:order-1 flex lg:flex-col gap-3">
              {views.map(([v, label]) => (
                <button key={v} type="button" onClick={() => setView(v)} aria-label={"Show " + label + " view"} aria-pressed={view === v}
                  className={"w-[22%] lg:w-full aspect-[3/4] rounded-lg overflow-hidden border-2 transition-colors " + (view === v ? "border-charcoal" : "border-transparent")}>
                  <ProductImage p={p} color={color} view={v} />
                </button>
              ))}
            </div>
            <div className="order-1 lg:order-2 aspect-[3/4] rounded-[14px] overflow-hidden bg-softgray zoom">
              <div key={view + color} className="w-full h-full zt fade"><ProductImage p={p} color={color} view={view} /></div>
            </div>
          </div>

          <div className="lg:col-span-5 lg:sticky lg:self-start" style={{ top: "calc(env(safe-area-inset-top,0px) + 100px)" }}>
            <div className="flex items-center gap-3">
              <p className="eyebrow">{p.category}</p>
              {p.isNew && <span className="bg-sage/40 text-[10.5px] tracking-[.16em] uppercase font-semibold px-2.5 py-1 rounded-full">New Arrival</span>}
            </div>
            <div className="flex items-start justify-between gap-4 mt-3">
              <h1 className="font-display text-[clamp(2.2rem,4vw,3.2rem)] leading-[1.04] text-balance">{p.name}</h1>
              <button type="button" onClick={() => s.toggleWish(p.id)} aria-pressed={wished} aria-label={wished ? "Remove from wishlist" : "Add to wishlist"} className="w-12 h-12 shrink-0 rounded-full border border-line grid place-items-center hover:bg-white"><Icon name="Heart" size={20} className={wished ? "fill-charcoal" : ""} /></button>
            </div>
            <p className="text-[22px] mt-3 tabular-nums">{fmt(p.price)}</p>
            <p className="text-[15.5px] text-charcoal/75 leading-relaxed mt-5">{p.description}</p>

            <p className="text-[13px] mt-7 mb-2"><span className="font-semibold">Colour:</span> {color}</p>
            <div className="flex -ml-[3px]">{p.colors.map((c) => <Swatch key={c} color={c} on={c === color} onClick={() => setColor(c)} size={30} />)}</div>

            <div ref={sizeRef} className={"mt-7 " + (err ? "shake" : "")}>
              <div className="flex items-center justify-between mb-2">
                <p className="text-[13px]"><span className="font-semibold">Size:</span> {size || "Select a size"}</p>
                <button type="button" className="inline-flex items-center gap-1.5 text-[12.5px] underline underline-offset-4" onClick={() => s.set({ sizeGuide: true })}><Icon name="Ruler" size={15} /> Size guide</button>
              </div>
              <div className="flex flex-wrap gap-2">
                {ALL_SIZES.map((z) => <button key={z} type="button" disabled={!p.sizes.includes(z)} className={"chip !min-w-[56px] " + (size === z ? "on" : "")} aria-pressed={size === z} onClick={() => { setSize(z); setErr(false); }}>{z}</button>)}
              </div>
              {err && <p className="text-[13px] text-[#9E3B2F] mt-2" role="alert">Please choose a size to continue.</p>}
            </div>

            <div className="flex gap-3 mt-7">
              <Qty qty={qty} setQty={setQty} />
              <button type="button" className="btn btn-dark flex-1" onClick={add}>Add to Cart</button>
            </div>
            <button type="button" className="btn btn-line w-full mt-3" onClick={buyNow}>Buy Now</button>

            <ul className="mt-7 grid gap-3 text-[13.5px]">
              <li className="flex gap-3"><Icon name="Truck" size={19} className="shrink-0 mt-0.5" /><span>Islandwide delivery in 2–4 working days. Free over {fmt(CONFIG.freeDeliveryOver)}.</span></li>
              <li className="flex gap-3"><Icon name="RotateCcw" size={19} className="shrink-0 mt-0.5" /><span>Easy exchanges within 7 days of delivery.</span></li>
            </ul>

            <div className="mt-8">
              <Accordion title="Product details" open><ul className="list-disc pl-5 grid gap-1.5">{p.details.map((d) => <li key={d}>{d}</li>)}</ul></Accordion>
              <Accordion title="Fabric &amp; care"><p>{p.fabric}</p></Accordion>
              <Accordion title="Model sizing"><p>{MODEL_INFO} If you are between sizes, we suggest sizing up for a relaxed fit.</p></Accordion>
              <Accordion title="Delivery information"><p>Colombo and suburbs: 1–2 working days. Other districts: 2–4 working days. Delivery is {fmt(CONFIG.deliveryFee)}, and free on orders over {fmt(CONFIG.freeDeliveryOver)}. Cash on delivery is available islandwide.</p></Accordion>
              <Accordion title="Return information"><p>Exchange or return unworn items with tags attached within 7 days of delivery. Contact us on WhatsApp or by email and we will arrange a pickup.</p></Accordion>
            </div>
          </div>
        </div>
      </div>

      <section className="wrap pt-24">
        <SectionHead eyebrow="Pairs well with" title="You may also like" />
        <ProductGrid items={related} />
      </section>

      <div className="lg:hidden fixed inset-x-0 bottom-0 z-40 bg-white border-t border-line flex items-center gap-4 pt-3" style={{ paddingBottom: "calc(env(safe-area-inset-bottom,0px) + 12px)", paddingLeft: "max(16px,env(safe-area-inset-left,0px))", paddingRight: "max(16px,env(safe-area-inset-right,0px))" }}>
        <div className="min-w-0">
          <p className="text-[13px] truncate">{p.name}</p>
          <p className="text-[15px] font-semibold tabular-nums">{fmt(p.price * qty)}</p>
        </div>
        <button type="button" className="btn btn-dark flex-1" onClick={add}>{size ? "Add to Cart" : "Select Size"}</button>
      </div>
    </div>
  );
}
