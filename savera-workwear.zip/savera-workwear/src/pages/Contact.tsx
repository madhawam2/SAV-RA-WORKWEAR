import { Icon } from "../components/Icon";
import { Accordion } from "../components/ui";
import { CONFIG } from "../config";

export function ContactPage() {
  const faqs = [
    ["How long does delivery take?", "Colombo and suburbs take 1–2 working days. Other districts take 2–4 working days."],
    ["Can I exchange an item?", "Yes. Unworn items with tags attached can be exchanged within 7 days of delivery."],
    ["How do I choose my size?", "Open the size guide on any product page. If you are between sizes, size up for a relaxed fit."],
    ["Can I order on WhatsApp?", "Yes. Use the Order via WhatsApp button in your bag or at checkout and your order is written for you."],
  ];
  return (
    <div className="wrap pt-10 lg:pt-16 max-w-[1000px]">
      <h1 className="font-display text-[clamp(2.6rem,6vw,4.6rem)] leading-none">Contact</h1>
      <p className="text-muted mt-3">We reply within one working day.</p>
      <div className="grid md:grid-cols-2 gap-10 mt-10">
        <ul className="grid gap-5 text-[15px]">
          <li className="flex gap-4"><Icon name="MapPin" size={20} className="mt-0.5 shrink-0" /><span>{CONFIG.contact.address}</span></li>
          <li className="flex gap-4"><Icon name="Phone" size={20} className="mt-0.5 shrink-0" /><span className="select-all">{CONFIG.contact.phone}</span></li>
          <li className="flex gap-4"><Icon name="Mail" size={20} className="mt-0.5 shrink-0" /><span className="select-all">{CONFIG.contact.email}</span></li>
          <li className="flex gap-4"><Icon name="Clock" size={20} className="mt-0.5 shrink-0" /><span>{CONFIG.contact.hours}</span></li>
          <li><a href={"https://wa.me/" + CONFIG.whatsappNumber} target="_blank" rel="noopener noreferrer" className="btn btn-dark"><Icon name="MessageCircle" size={17} /> Chat on WhatsApp</a></li>
        </ul>
        <div>{faqs.map(([q, a], i) => <Accordion key={q} title={q} open={i === 0}><p>{a}</p></Accordion>)}</div>
      </div>
    </div>
  );
}
