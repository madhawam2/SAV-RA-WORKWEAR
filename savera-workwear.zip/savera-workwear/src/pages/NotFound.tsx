export function NotFound() {
  return (
    <div className="wrap py-28 text-center">
      <p className="eyebrow">404</p>
      <h1 className="font-display text-[clamp(2.6rem,6vw,4.4rem)] leading-none mt-3">This page has moved.</h1>
      <a href="#home" className="btn btn-dark mt-8">Back to home</a>
    </div>
  );
}
