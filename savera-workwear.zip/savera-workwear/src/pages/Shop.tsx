import { useState, useEffect, useMemo } from "react";
import type { Size } from "../types";
import { Icon } from "../components/Icon";
import { ProductGrid } from "../components/ProductCard";
import { Panel, Swatch } from "../components/ui";
import { ALL_SIZES, CATEGORIES, PRODUCTS } from "../data/products";
import { SWATCH, searchProducts } from "../lib/helpers";
import { Bestsellers } from "./Home";
import { useStore } from "../store/StoreContext";

export const PRICE_BUCKETS = [
  { id: "u3", label: "Under Rs. 3,000", test: (n: number) => n < 3000 },
  { id: "m", label: "Rs. 3,000 – 4,000", test: (n: number) => n >= 3000 && n <= 4000 },
  { id: "o4", label: "Over Rs. 4,000", test: (n: number) => n > 4000 },
];

export const ALL_COLORS = Object.keys(SWATCH).filter((c) => PRODUCTS.some((p) => p.colors.includes(c)));

export function toggle<T>(arr: T[], v: T): T[] { return arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]; }

export function FilterPanel({ f, setF, close }: { f: any; setF: (x: any) => void; close?: () => void }) {
  return (
    <div className="grid gap-9">
      <div>
        <h3 className="eyebrow mb-3 !text-charcoal">Price</h3>
        <div className="flex flex-wrap gap-2">
          {PRICE_BUCKETS.map((b) => <button key={b.id} type="button" className={"chip " + (f.price.includes(b.id) ? "on" : "")} aria-pressed={f.price.includes(b.id)} onClick={() => setF({ ...f, price: toggle(f.price, b.id) })}>{b.label}</button>)}
        </div>
      </div>
      <div>
        <h3 className="eyebrow mb-3 !text-charcoal">Size</h3>
        <div className="flex flex-wrap gap-2">
          {ALL_SIZES.map((z) => <button key={z} type="button" className={"chip " + (f.sizes.includes(z) ? "on" : "")} aria-pressed={f.sizes.includes(z)} onClick={() => setF({ ...f, sizes: toggle(f.sizes, z) })}>{z}</button>)}
        </div>
      </div>
      <div>
        <h3 className="eyebrow mb-3 !text-charcoal">Colour</h3>
        <div className="flex flex-wrap gap-1 -ml-1">
          {ALL_COLORS.map((c) => <Swatch key={c} color={c} size={28} on={f.colors.includes(c)} onClick={() => setF({ ...f, colors: toggle(f.colors, c) })} />)}
        </div>
        {f.colors.length > 0 && <p className="text-[12.5px] text-muted mt-2">{f.colors.join(", ")}</p>}
      </div>
      <div>
        <label className="flex items-center gap-3 text-[14px] cursor-pointer min-h-[44px]">
          <input type="checkbox" className="w-5 h-5 accent-[#292925]" checked={f.bestOnly} onChange={(e: any) => setF({ ...f, bestOnly: e.target.checked })} />
          Bestsellers only
        </label>
      </div>
      {close && <button type="button" className="btn btn-dark w-full" onClick={close}>Show results</button>}
    </div>
  );
}

export function ShopPage({ route }: { route: string }) {
  const s = useStore();
  const preset = route === "new-arrivals" ? "new" : route === "bestsellers" ? "best" : null;
  const cat = CATEGORIES.find((c) => c.route === route) || CATEGORIES[0];
  const [f, setF] = useState<any>({ price: [], sizes: [], colors: [], bestOnly: false });
  const [sort, setSort] = useState<string>(preset === "new" ? "newest" : preset === "best" ? "best" : "featured");
  useEffect(() => { setSort(preset === "new" ? "newest" : preset === "best" ? "best" : "featured"); }, [route]);

  const items = useMemo(() => {
    let list = searchProducts(s.query);
    if (cat.match) list = list.filter((p) => p.category === cat.match);
    if (preset === "new") list = list.filter((p) => p.isNew);
    if (preset === "best") list = list.filter((p) => p.best);
    if (f.price.length) list = list.filter((p) => PRICE_BUCKETS.some((b) => f.price.includes(b.id) && b.test(p.price)));
    if (f.sizes.length) list = list.filter((p) => f.sizes.some((z: Size) => p.sizes.includes(z)));
    if (f.colors.length) list = list.filter((p) => f.colors.some((c: string) => p.colors.includes(c)));
    if (f.bestOnly) list = list.filter((p) => p.best);
    const sorted = [...list];
    if (sort === "newest") sorted.sort((a, b) => b.added - a.added);
    else if (sort === "low") sorted.sort((a, b) => a.price - b.price);
    else if (sort === "high") sorted.sort((a, b) => b.price - a.price);
    else if (sort === "best") sorted.sort((a, b) => Number(b.best) - Number(a.best) || b.added - a.added);
    return sorted;
  }, [s.query, cat.id, preset, f, sort]);

  const activeCount = f.price.length + f.sizes.length + f.colors.length + (f.bestOnly ? 1 : 0);
  const clear = () => { setF({ price: [], sizes: [], colors: [], bestOnly: false }); s.setQuery(""); };
  const title = preset === "new" ? "New Arrivals" : preset === "best" ? "Bestsellers" : cat.label;

  return (
    <div className="wrap pt-10 lg:pt-16">
      <nav className="text-[12.5px] text-muted mb-6" aria-label="Breadcrumb"><a href="#home" className="link-u">Home</a> / <span className="text-charcoal">{title}</span></nav>
      <h1 className="font-display text-[clamp(2.6rem,6vw,4.6rem)] leading-none">{title}</h1>
      <p className="text-muted mt-3 max-w-[520px]">Minimal, comfortable workwear designed in Sri Lanka.</p>

      <div className="mt-8 flex gap-2 overflow-x-auto no-scrollbar -mx-1 px-1 pb-1">
        {CATEGORIES.map((c) => <a key={c.id} href={"#" + c.route} className={"chip whitespace-nowrap flex items-center " + (!preset && c.id === cat.id ? "on" : "")}>{c.label}</a>)}
      </div>

      <div className="mt-6 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
        <div className="relative sm:w-[340px]">
          <label htmlFor="shop-search" className="sr-only">Search products</label>
          <Icon name="Search" size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted pointer-events-none" />
          <input id="shop-search" className="field !pl-11 !pr-11" placeholder="Search products" value={s.query} onChange={(e: any) => s.setQuery(e.target.value)} />
          {s.query && <button type="button" onClick={() => s.setQuery("")} aria-label="Clear search" className="absolute right-1 top-1/2 -translate-y-1/2 w-11 h-11 grid place-items-center"><Icon name="X" size={16} /></button>}
        </div>
        <div className="flex gap-3 items-center">
          <button type="button" className="btn btn-line lg:hidden flex-1 sm:flex-none" onClick={() => s.set({ filters: true })}><Icon name="SlidersHorizontal" size={16} /> Filters{activeCount ? " (" + activeCount + ")" : ""}</button>
          <div className="flex-1 sm:flex-none">
            <label htmlFor="sort" className="sr-only">Sort by</label>
            <select id="sort" className="field sm:w-[230px]" value={sort} onChange={(e: any) => setSort(e.target.value)}>
              <option value="featured">Sort: Featured</option>
              <option value="newest">Newest</option>
              <option value="low">Price: Low to High</option>
              <option value="high">Price: High to Low</option>
              <option value="best">Bestselling</option>
            </select>
          </div>
        </div>
      </div>

      <div className="mt-10 grid lg:grid-cols-[250px_1fr] gap-12">
        <aside className="hidden lg:block sticky self-start" style={{ top: "calc(env(safe-area-inset-top,0px) + 100px)" }} aria-label="Filters"><FilterPanel f={f} setF={setF} /></aside>
        <div>
          <div className="flex items-center justify-between mb-6 text-[13.5px] text-muted">
            <p aria-live="polite">{items.length} {items.length === 1 ? "piece" : "pieces"}</p>
            {(activeCount > 0 || s.query) && <button type="button" onClick={clear} className="underline underline-offset-4 text-charcoal">Clear all</button>}
          </div>
          {items.length === 0 ? (
            <div className="text-center py-20 bg-white/60 rounded-[14px]">
              <h2 className="font-display text-[2rem]">Nothing matches just yet</h2>
              <p className="text-muted mt-2">Try removing a filter or searching for something else.</p>
              <button type="button" className="btn btn-dark mt-6" onClick={clear}>Clear filters</button>
            </div>
          ) : <ProductGrid items={items} cols="grid-cols-2 md:grid-cols-3" />}
        </div>
      </div>

      <Panel open={s.ui.filters} onClose={() => s.set({ filters: false })} side="left" label="Filters">
        <div className="flex items-center justify-between px-5 h-[64px] border-b border-line shrink-0">
          <h2 className="font-display text-[1.7rem]">Filters</h2>
          <button type="button" className="w-11 h-11 -mr-2 grid place-items-center" onClick={() => s.set({ filters: false })} aria-label="Close filters"><Icon name="X" size={22} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-5"><FilterPanel f={f} setF={setF} close={() => s.set({ filters: false })} /></div>
      </Panel>
    </div>
  );
}
