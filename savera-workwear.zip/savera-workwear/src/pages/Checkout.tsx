import { useState } from "react";
import type { CartLine, Customer } from "../types";
import { ProductImage } from "../components/Garment";
import { Icon } from "../components/Icon";
import { Qty } from "../components/ui";
import { CONFIG } from "../config";
import { DISTRICTS } from "../data/content";
import { byId, fmt, lineKey } from "../lib/helpers";
import { PaymentGateway } from "../lib/payment";
import { save } from "../lib/storage";
import { buildWhatsAppMessage, waLink } from "../lib/whatsapp";
import { useStore } from "../store/StoreContext";

export function OrderSummary({ compact = false }: { compact?: boolean }) {
  const s = useStore();
  return (
    <div>
      <ul className="grid gap-4">
        {s.cart.map((l: CartLine) => {
          const p = byId(l.id)!;
          return (
            <li key={lineKey(l)} className="flex gap-4 items-center">
              <div className="relative w-16 shrink-0 aspect-[3/4] rounded-md overflow-hidden bg-softgray">
                <ProductImage p={p} color={l.color} />
                <span className="absolute -top-0 -right-0 min-w-[20px] h-5 px-1 bg-charcoal text-cream text-[11px] grid place-items-center rounded-bl-md tabular-nums">{l.qty}</span>
              </div>
              <div className="flex-1 min-w-0"><p className="text-[14px] leading-snug">{p.name}</p><p className="text-[12.5px] text-muted">{l.color} · {l.size}</p></div>
              <p className="text-[14px] tabular-nums">{fmt(p.price * l.qty)}</p>
            </li>
          );
        })}
      </ul>
      <dl className="mt-6 pt-5 border-t border-line text-[14px] grid gap-2 tabular-nums">
        <div className="flex justify-between"><dt className="text-muted">Subtotal</dt><dd>{fmt(s.totals.subtotal)}</dd></div>
        <div className="flex justify-between"><dt className="text-muted">Delivery</dt><dd>{s.totals.delivery === 0 ? "Free" : fmt(s.totals.delivery)}</dd></div>
        <div className="flex justify-between text-[18px] font-semibold pt-3 mt-1 border-t border-line"><dt>Total</dt><dd>{fmt(s.totals.total)}</dd></div>
      </dl>
    </div>
  );
}

export function Field({ id, label, error, children }: { id: string; label: string; error?: string; children: any }) {
  return (
    <div>
      <label htmlFor={id} className="block text-[12.5px] mb-1.5 font-medium">{label}</label>
      {children}
      {error && <p className="text-[12.5px] text-[#9E3B2F] mt-1.5" role="alert">{error}</p>}
    </div>
  );
}

export function CheckoutPage() {
  const s = useStore();
  const c: Customer = s.customer;
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const up = (k: keyof Customer, v: string) => { s.setCustomer({ ...c, [k]: v }); if (errors[k]) setErrors({ ...errors, [k]: "" }); };

  if (s.cart.length === 0) {
    return (
      <div className="wrap py-24 text-center">
        <h1 className="font-display text-[3rem]">Your bag is empty</h1>
        <p className="text-muted mt-3">Add a few pieces before checking out.</p>
        <a href="#shop" className="btn btn-dark mt-8">Continue shopping</a>
      </div>
    );
  }

  const validate = () => {
    const e: Record<string, string> = {};
    if (c.name.trim().length < 2) e.name = "Please enter your full name.";
    if (!/^(?:\+94|0)?7\d{8}$/.test(c.phone.replace(/[\s-]/g, ""))) e.phone = "Enter a valid Sri Lankan mobile number, e.g. 077 123 4567.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c.email)) e.email = "Please enter a valid email address.";
    if (c.address.trim().length < 5) e.address = "Please enter your delivery address.";
    if (!c.city.trim()) e.city = "Please enter your city.";
    if (!c.district) e.district = "Please choose a district.";
    if (!/^\d{5}$/.test(c.postal.trim())) e.postal = "Enter a 5-digit postal code.";
    setErrors(e);
    return e;
  };

  const submit = async (ev: any) => {
    ev.preventDefault();
    const e = validate();
    const first = Object.keys(e)[0];
    if (first) { const el = document.getElementById("co-" + first); if (el) el.focus(); return; }
    setBusy(true);
    const order = {
      customer: c, items: s.cart, subtotal: s.totals.subtotal, delivery: s.totals.delivery, total: s.totals.total, payment: c.payment,
    };
    const res = await PaymentGateway.createOrder(order);
    const placed = { ...order, orderId: res.orderId, status: res.status, placedAt: new Date().toISOString() };
    save("elan_last_order_v1", placed);
    s.setLastOrder(placed);
    s.clearCart();
    setBusy(false);
    location.hash = "order-confirmed";
  };

  const msg = buildWhatsAppMessage(s.cart, c, s.totals.subtotal, s.totals.delivery);

  return (
    <div className="wrap pt-10 lg:pt-16">
      <h1 className="font-display text-[clamp(2.6rem,6vw,4.4rem)] leading-none">Checkout</h1>
      <p className="text-muted mt-3 flex items-center gap-2"><Icon name="Lock" size={15} /> Demo checkout. No payment is taken on this site.</p>
      <form onSubmit={submit} noValidate className="mt-10 grid lg:grid-cols-[1fr_430px] gap-10 lg:gap-16 items-start">
        <div className="grid gap-10">
          <section aria-labelledby="h-contact">
            <h2 id="h-contact" className="font-display text-[1.9rem] mb-5">Contact</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2"><Field id="co-name" label="Full name" error={errors.name}><input id="co-name" className={"field " + (errors.name ? "err" : "")} autoComplete="name" value={c.name} onChange={(e: any) => up("name", e.target.value)} /></Field></div>
              <Field id="co-phone" label="Phone number" error={errors.phone}><input id="co-phone" type="tel" inputMode="tel" placeholder="077 123 4567" className={"field " + (errors.phone ? "err" : "")} autoComplete="tel" value={c.phone} onChange={(e: any) => up("phone", e.target.value)} /></Field>
              <Field id="co-email" label="Email" error={errors.email}><input id="co-email" type="email" inputMode="email" className={"field " + (errors.email ? "err" : "")} autoComplete="email" value={c.email} onChange={(e: any) => up("email", e.target.value)} /></Field>
            </div>
          </section>

          <section aria-labelledby="h-delivery">
            <h2 id="h-delivery" className="font-display text-[1.9rem] mb-5">Delivery</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2"><Field id="co-address" label="Delivery address" error={errors.address}><input id="co-address" className={"field " + (errors.address ? "err" : "")} autoComplete="street-address" value={c.address} onChange={(e: any) => up("address", e.target.value)} /></Field></div>
              <Field id="co-city" label="City" error={errors.city}><input id="co-city" className={"field " + (errors.city ? "err" : "")} autoComplete="address-level2" value={c.city} onChange={(e: any) => up("city", e.target.value)} /></Field>
              <Field id="co-district" label="District" error={errors.district}>
                <select id="co-district" className={"field " + (errors.district ? "err" : "")} value={c.district} onChange={(e: any) => up("district", e.target.value)}>
                  <option value="">Select district</option>
                  {DISTRICTS.map((d) => <option key={d}>{d}</option>)}
                </select>
              </Field>
              <Field id="co-postal" label="Postal code" error={errors.postal}><input id="co-postal" inputMode="numeric" maxLength={5} className={"field " + (errors.postal ? "err" : "")} autoComplete="postal-code" value={c.postal} onChange={(e: any) => up("postal", e.target.value.replace(/\D/g, ""))} /></Field>
              <div className="sm:col-span-2"><Field id="co-notes" label="Order notes (optional)"><textarea id="co-notes" rows={3} className="field !h-auto py-3" placeholder="Delivery instructions, preferred call time…" value={c.notes} onChange={(e: any) => up("notes", e.target.value)} /></Field></div>
            </div>
          </section>

          <section aria-labelledby="h-pay">
            <h2 id="h-pay" className="font-display text-[1.9rem] mb-5">Payment</h2>
            <div className="grid gap-3" role="radiogroup" aria-label="Payment method">
              {([["cod", "Cash on Delivery", "Pay in cash when your order arrives."], ["bank", "Bank Transfer", "Transfer to our account and send the receipt on WhatsApp."]] as const).map(([v, t, d]) => (
                <label key={v} className={"flex gap-4 items-start p-4 rounded-[10px] border cursor-pointer transition-colors " + (c.payment === v ? "border-charcoal bg-white" : "border-line hover:border-charcoal/50")}>
                  <input type="radio" name="payment" className="mt-1 w-5 h-5 accent-[#292925]" checked={c.payment === v} onChange={() => up("payment", v)} />
                  <span><span className="block font-medium text-[14.5px]">{t}</span><span className="block text-[13.5px] text-muted mt-0.5">{d}</span></span>
                </label>
              ))}
            </div>
            {c.payment === "bank" && (
              <dl className="mt-4 p-5 rounded-[10px] bg-beige text-[14px] grid grid-cols-[auto_1fr] gap-x-6 gap-y-1.5 pop">
                <dt className="text-muted">Bank</dt><dd>{CONFIG.bank.bank}</dd>
                <dt className="text-muted">Account name</dt><dd>{CONFIG.bank.accountName}</dd>
                <dt className="text-muted">Account no.</dt><dd className="select-all">{CONFIG.bank.accountNumber}</dd>
                <dt className="text-muted">Branch</dt><dd>{CONFIG.bank.branch}</dd>
              </dl>
            )}
          </section>
        </div>

        <aside className="lg:sticky self-start bg-white rounded-[14px] p-6 lg:p-8" style={{ top: "calc(env(safe-area-inset-top,0px) + 96px)" }} aria-label="Order summary">
          <h2 className="font-display text-[1.9rem] mb-5">Order summary</h2>
          <OrderSummary />
          <button type="submit" disabled={busy} className="btn btn-dark w-full mt-6">{busy ? "Placing order…" : "Place Order"}</button>
          <div className="flex items-center gap-3 my-4 text-[12px] text-muted"><span className="flex-1 h-px bg-line" />or<span className="flex-1 h-px bg-line" /></div>
          <a href={waLink(msg)} target="_blank" rel="noopener noreferrer" className="btn btn-line w-full"><Icon name="MessageCircle" size={17} /> Order via WhatsApp</a>
          <details className="mt-4 text-[13px]">
            <summary className="cursor-pointer text-muted">Preview WhatsApp message</summary>
            <pre className="mt-2 p-3 bg-cream rounded-lg whitespace-pre-wrap text-[12px] leading-relaxed font-sans">{msg}</pre>
          </details>
          <a href="#shop" className="block text-center text-[13px] underline underline-offset-4 mt-5">Continue shopping</a>
        </aside>
      </form>
    </div>
  );
}

export function ConfirmationPage() {
  const s = useStore();
  const o = s.lastOrder;
  if (!o) return <div className="wrap py-24 text-center"><h1 className="font-display text-[3rem]">No recent order</h1><a href="#shop" className="btn btn-dark mt-8">Start shopping</a></div>;
  const msg = buildWhatsAppMessage(o.items, o.customer, o.subtotal, o.delivery) + "\n\nOrder ref: " + o.orderId;
  return (
    <div className="wrap py-16 lg:py-24 max-w-[760px]">
      <div className="w-14 h-14 rounded-full bg-sage grid place-items-center"><Icon name="Check" size={26} sw={2} /></div>
      <p className="eyebrow mt-8">Order {o.orderId}</p>
      <h1 className="font-display text-[clamp(2.6rem,6vw,4.4rem)] leading-none mt-3">Thank you, {o.customer.name.split(" ")[0]}.</h1>
      <p className="text-[16px] text-charcoal/75 mt-5 leading-relaxed">
        {o.payment === "bank"
          ? "Please transfer " + fmt(o.total) + " to the account below and send your receipt on WhatsApp. We will dispatch once it is confirmed."
          : "Your order will be delivered to " + o.customer.city + " within 2–4 working days. Please keep " + fmt(o.total) + " ready in cash."}
      </p>
      <p className="text-[13px] text-muted mt-3">This is a demo order. No payment was taken and nothing has been sent to a real store.</p>
      <div className="bg-white rounded-[14px] p-6 lg:p-8 mt-10">
        <ul className="grid gap-4">
          {o.items.map((l: CartLine) => { const p = byId(l.id); if (!p) return null; return (
            <li key={lineKey(l)} className="flex justify-between gap-4 text-[14.5px]"><span>{p.name}<span className="block text-[12.5px] text-muted">{l.color} · {l.size} · Qty {l.qty}</span></span><span className="tabular-nums">{fmt(p.price * l.qty)}</span></li>
          ); })}
        </ul>
        <dl className="mt-5 pt-4 border-t border-line text-[14px] grid gap-1.5 tabular-nums">
          <div className="flex justify-between"><dt className="text-muted">Subtotal</dt><dd>{fmt(o.subtotal)}</dd></div>
          <div className="flex justify-between"><dt className="text-muted">Delivery</dt><dd>{o.delivery === 0 ? "Free" : fmt(o.delivery)}</dd></div>
          <div className="flex justify-between font-semibold text-[16px]"><dt>Total</dt><dd>{fmt(o.total)}</dd></div>
        </dl>
        <p className="text-[13.5px] text-muted mt-5">Delivering to: {[o.customer.address, o.customer.city, o.customer.district, o.customer.postal].filter(Boolean).join(", ")}</p>
      </div>
      <div className="flex flex-col sm:flex-row gap-3 mt-8">
        <a href={waLink(msg)} target="_blank" rel="noopener noreferrer" className="btn btn-dark"><Icon name="MessageCircle" size={17} /> Confirm on WhatsApp</a>
        <a href="#shop" className="btn btn-line">Continue shopping</a>
      </div>
    </div>
  );
}
