import { Icon } from "../components/Icon";
import { ProductGrid } from "../components/ProductCard";
import { PRODUCTS } from "../data/products";
import { save } from "../lib/storage";
import { useStore } from "../store/StoreContext";

export function WishlistPage() {
  const s = useStore();
  const items = PRODUCTS.filter((p) => s.wishlist.includes(p.id));
  return (
    <div className="wrap pt-10 lg:pt-16">
      <h1 className="font-display text-[clamp(2.6rem,6vw,4.6rem)] leading-none">Wishlist</h1>
      <p className="text-muted mt-3">{items.length ? items.length + " saved " + (items.length === 1 ? "piece" : "pieces") : "Pieces you save will be waiting here."}</p>
      <div className="mt-10">
        {items.length ? <ProductGrid items={items} /> : (
          <div className="text-center py-20 bg-white/60 rounded-[14px]">
            <div className="mx-auto w-16 h-16 rounded-full bg-beige grid place-items-center mb-5"><Icon name="Heart" size={26} /></div>
            <h2 className="font-display text-[2rem]">Nothing saved yet</h2>
            <p className="text-muted mt-2">Tap the heart on any piece to save it.</p>
            <a href="#shop" className="btn btn-dark mt-6">Browse the collection</a>
          </div>
        )}
      </div>
    </div>
  );
}
