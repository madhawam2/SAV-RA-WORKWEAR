import type { CartLine, Customer, Size } from "../types";
import { Qty } from "../components/ui";
import { CONFIG } from "../config";
import { byId, fmt } from "./helpers";

// WhatsApp ordering ----------------------------------------------------
export function buildWhatsAppMessage(lines: CartLine[], c: Partial<Customer>, subtotal: number, delivery: number) {
  const out: string[] = [];
  out.push("Hello " + CONFIG.brand.short + "! I would like to place an order.");
  out.push("");
  out.push("*Customer*");
  out.push("Name: " + (c.name || "(please add your name)"));
  if (c.phone) out.push("Phone: " + c.phone);
  out.push("");
  out.push("*Order*");
  lines.forEach((l, i) => {
    const p = byId(l.id);
    if (!p) return;
    out.push((i + 1) + ". " + p.name + " | Size " + l.size + " | " + l.color + " | Qty " + l.qty + " | " + fmt(p.price * l.qty));
  });
  out.push("");
  out.push("Subtotal: " + fmt(subtotal));
  out.push("Delivery: " + (delivery === 0 ? "Free" : fmt(delivery)));
  out.push("*Total: " + fmt(subtotal + delivery) + "*");
  out.push("");
  out.push("*Delivery details*");
  const addr = [c.address, c.city, c.district, c.postal].filter(Boolean).join(", ");
  out.push(addr || "(address to be confirmed)");
  if (c.payment) out.push("Payment: " + (c.payment === "bank" ? "Bank transfer" : "Cash on delivery"));
  if (c.notes) out.push("Notes: " + c.notes);
  return out.join("\n");
}

export const waLink = (msg: string) => "https://wa.me/" + CONFIG.whatsappNumber + "?text=" + encodeURIComponent(msg);
