import type { Product } from "../types";
import { CONFIG } from "../config";
import { PRODUCTS } from "../data/products";

export const SWATCH: Record<string, string> = {
  Ivory: "#F1ECE2", Sand: "#D9CBB4", Sage: "#A3B09E", Charcoal: "#3B3B36", Oat: "#E4DAC8",
  Mocha: "#8C7765", Stone: "#C8C4B9", Black: "#242421", Blush: "#DDC4BC",
};

export const fmt = (n: number) => "Rs. " + Math.round(n).toLocaleString("en-US");

export const byId = (id: string) => PRODUCTS.find((p) => p.id === id);

export const deliveryFor = (subtotal: number) => (subtotal === 0 || subtotal >= CONFIG.freeDeliveryOver ? 0 : CONFIG.deliveryFee);

export const lineKey = (l: { id: string; color: string; size: string }) => l.id + "|" + l.color + "|" + l.size;

export function hexToRgb(h: string) {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function mix(a: string, b: string, t: number) {
  const A = hexToRgb(a), B = hexToRgb(b);
  const c = A.map((v, i) => Math.round(v + (B[i] - v) * t));
  return "rgb(" + c[0] + "," + c[1] + "," + c[2] + ")";
}

export function isDark(hex: string) {
  const [r, g, b] = hexToRgb(hex);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b < 110;
}

export function searchProducts(q: string): Product[] {
  const t = q.trim().toLowerCase();
  if (!t) return PRODUCTS;
  const words = t.split(/\s+/);
  return PRODUCTS.filter((p) => {
    const hay = (p.name + " " + p.category + " " + p.colors.join(" ") + " " + p.kind + " " + p.description).toLowerCase();
    return words.every((w) => hay.includes(w));
  });
}
