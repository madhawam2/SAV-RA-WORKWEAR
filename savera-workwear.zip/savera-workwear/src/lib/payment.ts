// Payment gateway adapter ---------------------------------------------
// Demo only: no payment is taken. To go live, replace createOrder with a call to
// your gateway (for example PayHere, Stripe, or Genie) and redirect to its hosted page.
export const PaymentGateway = {
  async createOrder(order: any): Promise<{ orderId: string; status: string }> {
    await new Promise((r) => setTimeout(r, 700));
    return { orderId: "EW-" + Date.now().toString(36).toUpperCase().slice(-6), status: order.payment === "cod" ? "confirmed-cod" : "awaiting-transfer" };
  },
};
