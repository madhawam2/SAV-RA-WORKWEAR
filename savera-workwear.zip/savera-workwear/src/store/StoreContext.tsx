import { useState, useEffect, useMemo, useRef, useCallback, createContext, useContext } from "react";
import type { CartLine, Customer, Size } from "../types";
import { byId, deliveryFor, lineKey } from "../lib/helpers";
import { load, save } from "../lib/storage";

export const Store = createContext<any>(null);

export const useStore = () => useContext(Store);

export const emptyCustomer: Customer = { name: "", phone: "", email: "", address: "", city: "", district: "", postal: "", notes: "", payment: "cod" };

export function useHashRoute() {
  const read = () => (location.hash || "").replace(/^#/, "") || "home";
  const [route, setRoute] = useState<string>(read());
  useEffect(() => {
    const on = () => { setRoute(read()); window.scrollTo(0, 0); };
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return route;
}

export function StoreProvider({ children }: { children: any }) {
  const route = useHashRoute();
  const [cart, setCart] = useState<CartLine[]>(() => load<CartLine[]>("elan_cart_v1", []).filter((l) => !!byId(l.id)));
  const [wishlist, setWishlist] = useState<string[]>(() => load<string[]>("elan_wish_v1", []));
  const [customer, setCustomer] = useState<Customer>(() => ({ ...emptyCustomer, ...load<Partial<Customer>>("elan_customer_v1", {}) }));
  const [lastOrder, setLastOrder] = useState<any>(() => load<any>("elan_last_order_v1", null));
  const [query, setQuery] = useState("");
  const [ui, setUi] = useState({ cart: false, menu: false, search: false, account: false, sizeGuide: false, filters: false, quick: null as string | null });
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<any>(null);

  useEffect(() => save("elan_cart_v1", cart), [cart]);
  useEffect(() => save("elan_wish_v1", wishlist), [wishlist]);
  useEffect(() => save("elan_customer_v1", customer), [customer]);

  useEffect(() => {
    setUi((u) => ({ ...u, menu: false, search: false, account: false, quick: null, filters: false, cart: false }));
  }, [route]);

  useEffect(() => {
    const open = ui.cart || ui.menu || ui.search || ui.account || ui.sizeGuide || ui.filters || ui.quick;
    document.body.style.overflow = open ? "hidden" : "";
  }, [ui]);

  const flash = useCallback((msg: string) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2400);
  }, []);

  const addToCart = useCallback((id: string, color: string, size: Size, qty = 1, openCart = true) => {
    setCart((prev) => {
      const key = lineKey({ id, color, size });
      const i = prev.findIndex((l) => lineKey(l) === key);
      if (i >= 0) return prev.map((l, j) => (j === i ? { ...l, qty: Math.min(10, l.qty + qty) } : l));
      return [...prev, { id, color, size, qty: Math.min(10, qty) }];
    });
    if (openCart) setUi((u) => ({ ...u, cart: true, quick: null }));
  }, []);

  const removeLine = useCallback((key: string) => setCart((prev) => prev.filter((l) => lineKey(l) !== key)), []);
  const setQty = useCallback((key: string, qty: number) => {
    setCart((prev) => prev.map((l) => (lineKey(l) === key ? { ...l, qty: Math.max(1, Math.min(10, qty)) } : l)));
  }, []);
  const changeVariant = useCallback((key: string, patch: { color?: string; size?: Size }) => {
    setCart((prev) => {
      const cur = prev.find((l) => lineKey(l) === key);
      if (!cur) return prev;
      const next = { ...cur, ...patch };
      const nk = lineKey(next);
      if (nk === key) return prev;
      const dupe = prev.find((l) => lineKey(l) === nk);
      if (dupe) return prev.filter((l) => lineKey(l) !== key).map((l) => (lineKey(l) === nk ? { ...l, qty: Math.min(10, l.qty + cur.qty) } : l));
      return prev.map((l) => (lineKey(l) === key ? next : l));
    });
  }, []);
  const clearCart = useCallback(() => setCart([]), []);

  const toggleWish = useCallback((id: string) => {
    setWishlist((prev) => {
      const has = prev.includes(id);
      flash(has ? "Removed from wishlist" : "Saved to wishlist");
      return has ? prev.filter((x) => x !== id) : [...prev, id];
    });
  }, [flash]);

  const totals = useMemo(() => {
    const subtotal = cart.reduce((s, l) => s + (byId(l.id)?.price || 0) * l.qty, 0);
    const delivery = deliveryFor(subtotal);
    const count = cart.reduce((s, l) => s + l.qty, 0);
    return { subtotal, delivery, total: subtotal + delivery, count };
  }, [cart]);

  const set = (patch: any) => setUi((u) => ({ ...u, ...patch }));
  const closeAll = () => setUi({ cart: false, menu: false, search: false, account: false, sizeGuide: false, filters: false, quick: null });

  const value = {
    route, cart, wishlist, customer, setCustomer, lastOrder, setLastOrder, query, setQuery, ui, set, closeAll, toast, flash,
    addToCart, removeLine, setQty, changeVariant, clearCart, toggleWish, totals,
  };
  return <Store.Provider value={value}>{children}</Store.Provider>;
}
