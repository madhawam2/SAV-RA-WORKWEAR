export const CONFIG = {
  brand: {
    name: "SAVÉRA WORKWEAR",
    short: "SAVÉRA",
    tagline: "Confidence in Every Workday.",
    description:
      "Thoughtfully designed workwear for women who move with confidence. Minimal, comfortable and made for the way you work in Sri Lanka.",
  },
  announcement: "Free delivery on orders over Rs. 10,000 | Islandwide delivery",
  freeDeliveryOver: 10000,
  deliveryFee: 450,
  // WhatsApp business number: country code + number, digits only (no + or spaces)
  whatsappNumber: "94770000000",
  contact: {
    email: "hello@saveraworkwear.lk",
    phone: "+94 77 000 0000",
    address: "No. 00, Galle Road, Colombo 03, Sri Lanka",
    hours: "Mon – Sat, 9.00 am – 6.00 pm",
  },
  social: {
    instagram: "https://instagram.com/saveraworkwear",
    facebook: "https://facebook.com/saveraworkwear",
    tiktok: "https://tiktok.com/@saveraworkwear",
  },
  bank: {
    bank: "Sample Bank PLC",
    accountName: "Savéra Workwear (Pvt) Ltd",
    accountNumber: "0000 0000 0000",
    branch: "Colombo 03",
  },
};
